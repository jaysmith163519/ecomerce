import { apiRequest, tokenManager, createUploadConfig } from './api';
import { ENDPOINTS } from '../config/api.config';
import {
  User,
  RegisterRequest,
  LoginRequest,
  AuthResponse,
  UpdateProfileRequest,
  ChangePasswordRequest,
  ApiResponse,
} from '../types/api.types';

class AuthService {
  // Register new user
  async register(userData: RegisterRequest): Promise<AuthResponse> {
    const response = await apiRequest<ApiResponse<AuthResponse>>({
      method: 'POST',
      url: ENDPOINTS.AUTH.REGISTER,
      data: userData,
    });
    
    // Store token and user data
    if (response.data.token) {
      tokenManager.setToken(response.data.token);
      localStorage.setItem('user', JSON.stringify(response.data.user));
    }
    
    return response.data;
  }

  // Login user
  async login(credentials: LoginRequest): Promise<AuthResponse> {
    const response = await apiRequest<ApiResponse<AuthResponse>>({
      method: 'POST',
      url: ENDPOINTS.AUTH.LOGIN,
      data: credentials,
    });
    
    // Store token and user data
    if (response.data.token) {
      tokenManager.setToken(response.data.token);
      localStorage.setItem('user', JSON.stringify(response.data.user));
    }
    
    return response.data;
  }

  // Get user profile
  async getProfile(): Promise<User> {
    const response = await apiRequest<ApiResponse<User>>({
      method: 'GET',
      url: ENDPOINTS.AUTH.PROFILE,
    });
    
    return response.data;
  }

  // Update user profile
  async updateProfile(profileData: UpdateProfileRequest): Promise<User> {
    const response = await apiRequest<ApiResponse<User>>({
      method: 'PUT',
      url: ENDPOINTS.AUTH.PROFILE,
      data: profileData,
    });
    
    // Update stored user data
    localStorage.setItem('user', JSON.stringify(response.data));
    
    return response.data;
  }

  // Change password
  async changePassword(passwordData: ChangePasswordRequest): Promise<void> {
    await apiRequest<ApiResponse<void>>({
      method: 'PUT',
      url: ENDPOINTS.AUTH.CHANGE_PASSWORD,
      data: passwordData,
    });
  }

  // Upload avatar
  async uploadAvatar(
    file: File, 
    onProgress?: (progress: number) => void
  ): Promise<User> {
    const formData = new FormData();
    formData.append('avatar', file);
    
    const response = await apiRequest<ApiResponse<User>>({
      method: 'POST',
      url: `${ENDPOINTS.AUTH.PROFILE}/avatar`,
      data: formData,
      ...createUploadConfig(onProgress),
    });
    
    // Update stored user data
    localStorage.setItem('user', JSON.stringify(response.data));
    
    return response.data;
  }

  // Logout user
  logout(): void {
    tokenManager.removeToken();
    localStorage.removeItem('user');
  }

  // Check if user is authenticated
  isAuthenticated(): boolean {
    const token = tokenManager.getToken();
    return token ? !tokenManager.isTokenExpired(token) : false;
  }

  // Get current user from localStorage
  getCurrentUser(): User | null {
    const userStr = localStorage.getItem('user');
    return userStr ? JSON.parse(userStr) : null;
  }

  // Get auth token
  getToken(): string | null {
    return tokenManager.getToken();
  }

  // Refresh user profile data
  async refreshProfile(): Promise<User> {
    const user = await this.getProfile();
    localStorage.setItem('user', JSON.stringify(user));
    return user;
  }
}

export default new AuthService();