import { apiRequest } from './api';
import { ENDPOINTS } from '../config/api.config';
import {
  Order,
  CreateOrderRequest,
  OrdersQuery,
  OrdersResponse,
  ApiResponse,
} from '../types/api.types';

class OrderService {
  // Get user's orders
  async getOrders(query: OrdersQuery = {}): Promise<OrdersResponse> {
    const params = new URLSearchParams();
    
    Object.entries(query).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== '') {
        params.append(key, value.toString());
      }
    });
    
    const response = await apiRequest<ApiResponse<OrdersResponse>>({
      method: 'GET',
      url: `${ENDPOINTS.ORDERS.BASE}?${params.toString()}`,
    });
    
    return response.data;
  }

  // Create new order
  async createOrder(orderData: CreateOrderRequest): Promise<Order> {
    const response = await apiRequest<ApiResponse<Order>>({
      method: 'POST',
      url: ENDPOINTS.ORDERS.BASE,
      data: orderData,
    });
    
    return response.data;
  }

  // Get order details
  async getOrder(id: string): Promise<Order> {
    const response = await apiRequest<ApiResponse<Order>>({
      method: 'GET',
      url: ENDPOINTS.ORDERS.BY_ID(id),
    });
    
    return response.data;
  }

  // Cancel order (if allowed)
  async cancelOrder(id: string): Promise<Order> {
    const response = await apiRequest<ApiResponse<Order>>({
      method: 'PUT',
      url: `${ENDPOINTS.ORDERS.BY_ID(id)}/cancel`,
    });
    
    return response.data;
  }

  // Track order
  async trackOrder(id: string): Promise<{
    order: Order;
    trackingInfo: any;
  }> {
    const response = await apiRequest<ApiResponse<{
      order: Order;
      trackingInfo: any;
    }>>({
      method: 'GET',
      url: `${ENDPOINTS.ORDERS.BY_ID(id)}/track`,
    });
    
    return response.data;
  }

  // Get order history with pagination
  async getOrderHistory(page: number = 1, limit: number = 10): Promise<OrdersResponse> {
    return this.getOrders({
      page,
      limit,
      sortBy: 'createdAt',
      sortOrder: 'desc',
    });
  }

  // Get orders by status
  async getOrdersByStatus(status: string, page: number = 1, limit: number = 10): Promise<OrdersResponse> {
    return this.getOrders({
      status,
      page,
      limit,
      sortBy: 'createdAt',
      sortOrder: 'desc',
    });
  }

  // Reorder (create new order from existing order)
  async reorder(orderId: string): Promise<Order> {
    const response = await apiRequest<ApiResponse<Order>>({
      method: 'POST',
      url: `${ENDPOINTS.ORDERS.BY_ID(orderId)}/reorder`,
    });
    
    return response.data;
  }

  // Download order invoice
  async downloadInvoice(orderId: string): Promise<Blob> {
    const response = await apiRequest<any>({
      method: 'GET',
      url: `${ENDPOINTS.ORDERS.BY_ID(orderId)}/invoice`,
      responseType: 'blob',
    });
    
    return response;
  }

  // Get order statistics for user dashboard
  async getOrderStats(): Promise<{
    totalOrders: number;
    totalSpent: number;
    averageOrderValue: number;
    statusBreakdown: Record<string, number>;
  }> {
    const response = await apiRequest<ApiResponse<{
      totalOrders: number;
      totalSpent: number;
      averageOrderValue: number;
      statusBreakdown: Record<string, number>;
    }>>({
      method: 'GET',
      url: `${ENDPOINTS.ORDERS.BASE}/stats`,
    });
    
    return response.data;
  }

  // Update order status (for sellers/admin)
  async updateOrderStatus(orderId: string, status: string): Promise<Order> {
    const response = await apiRequest<ApiResponse<Order>>({
      method: 'PUT',
      url: `${ENDPOINTS.ORDERS.BY_ID(orderId)}/status`,
      data: { status },
    });
    
    return response.data;
  }
}

export default new OrderService();