import { apiRequest, createUploadConfig, createCancelToken } from './api';
import { ENDPOINTS } from '../config/api.config';
import {
  Product,
  ProductsQuery,
  ProductsResponse,
  CreateProductRequest,
  Category,
  ApiResponse,
} from '../types/api.types';

class ProductService {
  private searchCancelToken: any = null;

  // Get products with filtering and pagination
  async getProducts(query: ProductsQuery = {}): Promise<ProductsResponse> {
    const params = new URLSearchParams();
    
    Object.entries(query).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== '') {
        params.append(key, value.toString());
      }
    });
    
    const response = await apiRequest<ApiResponse<ProductsResponse>>({
      method: 'GET',
      url: `${ENDPOINTS.PRODUCTS.BASE}?${params.toString()}`,
    });
    
    return response.data;
  }

  // Get single product by ID
  async getProduct(id: string): Promise<Product> {
    const response = await apiRequest<ApiResponse<Product>>({
      method: 'GET',
      url: ENDPOINTS.PRODUCTS.BY_ID(id),
    });
    
    return response.data;
  }

  // Get product categories
  async getCategories(): Promise<Category[]> {
    const response = await apiRequest<ApiResponse<Category[]>>({
      method: 'GET',
      url: '/categories',
    });
    
    return response.data;
  }

  // Create new product (seller/admin only)
  async createProduct(
    productData: CreateProductRequest,
    onProgress?: (progress: number) => void
  ): Promise<Product> {
    const formData = new FormData();
    
    // Add text fields
    Object.entries(productData).forEach(([key, value]) => {
      if (key === 'images') return; // Handle images separately
      if (key === 'variants' || key === 'inventory') {
        formData.append(key, JSON.stringify(value));
      } else {
        formData.append(key, value.toString());
      }
    });
    
    // Add image files
    if (productData.images) {
      productData.images.forEach((file, index) => {
        formData.append(`images`, file);
      });
    }
    
    const response = await apiRequest<ApiResponse<Product>>({
      method: 'POST',
      url: ENDPOINTS.PRODUCTS.BASE,
      data: formData,
      ...createUploadConfig(onProgress),
    });
    
    return response.data;
  }

  // Update product (seller/admin only)
  async updateProduct(
    id: string, 
    productData: Partial<CreateProductRequest>,
    onProgress?: (progress: number) => void
  ): Promise<Product> {
    const formData = new FormData();
    
    // Add text fields
    Object.entries(productData).forEach(([key, value]) => {
      if (key === 'images') return; // Handle images separately
      if (key === 'variants' || key === 'inventory') {
        formData.append(key, JSON.stringify(value));
      } else if (value !== undefined) {
        formData.append(key, value.toString());
      }
    });
    
    // Add image files
    if (productData.images) {
      productData.images.forEach((file, index) => {
        formData.append(`images`, file);
      });
    }
    
    const response = await apiRequest<ApiResponse<Product>>({
      method: 'PUT',
      url: ENDPOINTS.PRODUCTS.BY_ID(id),
      data: formData,
      ...createUploadConfig(onProgress),
    });
    
    return response.data;
  }

  // Delete product (seller/admin only)
  async deleteProduct(id: string): Promise<void> {
    await apiRequest<ApiResponse<void>>({
      method: 'DELETE',
      url: ENDPOINTS.PRODUCTS.BY_ID(id),
    });
  }

  // Search products with debouncing support
  async searchProducts(
    searchTerm: string, 
    filters: Omit<ProductsQuery, 'search'> = {}
  ): Promise<ProductsResponse> {
    // Cancel previous search request
    if (this.searchCancelToken) {
      this.searchCancelToken.cancel('New search initiated');
    }
    
    // Create new cancel token
    this.searchCancelToken = createCancelToken();
    
    return this.getProducts({
      ...filters,
      search: searchTerm,
    });
  }

  // Get products by category
  async getProductsByCategory(categoryId: string, query: Omit<ProductsQuery, 'category'> = {}): Promise<ProductsResponse> {
    return this.getProducts({
      ...query,
      category: categoryId,
    });
  }

  // Get featured products
  async getFeaturedProducts(limit: number = 8): Promise<Product[]> {
    const response = await this.getProducts({
      limit,
      sortBy: 'rating',
      sortOrder: 'desc',
    });
    
    return response.products;
  }

  // Get related products
  async getRelatedProducts(productId: string, limit: number = 4): Promise<Product[]> {
    const product = await this.getProduct(productId);
    const response = await this.getProducts({
      category: product.category._id,
      limit: limit + 1, // Get one extra to exclude current product
    });
    
    // Filter out the current product
    return response.products.filter(p => p._id !== productId).slice(0, limit);
  }

  // Get product recommendations based on user behavior
  async getRecommendedProducts(limit: number = 8): Promise<Product[]> {
    const response = await apiRequest<ApiResponse<Product[]>>({
      method: 'GET',
      url: `/products/recommended?limit=${limit}`,
    });
    
    return response.data;
  }

  // Get price range for filtering
  async getPriceRange(): Promise<{ min: number; max: number }> {
    const response = await apiRequest<ApiResponse<{ min: number; max: number }>>({
      method: 'GET',
      url: '/products/price-range',
    });
    
    return response.data;
  }
}

export default new ProductService();