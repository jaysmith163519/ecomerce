import { apiRequest } from './api';
import { ENDPOINTS } from '../config/api.config';
import {
  Cart,
  AddToCartRequest,
  UpdateCartItemRequest,
  ApiResponse,
} from '../types/api.types';

class CartService {
  // Get user's cart
  async getCart(): Promise<Cart> {
    const response = await apiRequest<ApiResponse<Cart>>({
      method: 'GET',
      url: ENDPOINTS.CART.BASE,
    });
    
    return response.data;
  }

  // Add item to cart
  async addToCart(itemData: AddToCartRequest): Promise<Cart> {
    const response = await apiRequest<ApiResponse<Cart>>({
      method: 'POST',
      url: ENDPOINTS.CART.ITEMS,
      data: itemData,
    });
    
    return response.data;
  }

  // Update cart item quantity
  async updateCartItem(itemId: string, updateData: UpdateCartItemRequest): Promise<Cart> {
    const response = await apiRequest<ApiResponse<Cart>>({
      method: 'PUT',
      url: ENDPOINTS.CART.ITEM_BY_ID(itemId),
      data: updateData,
    });
    
    return response.data;
  }

  // Remove item from cart
  async removeFromCart(itemId: string): Promise<Cart> {
    const response = await apiRequest<ApiResponse<Cart>>({
      method: 'DELETE',
      url: ENDPOINTS.CART.ITEM_BY_ID(itemId),
    });
    
    return response.data;
  }

  // Clear entire cart
  async clearCart(): Promise<void> {
    await apiRequest<ApiResponse<void>>({
      method: 'DELETE',
      url: ENDPOINTS.CART.BASE,
    });
  }

  // Apply coupon to cart
  async applyCoupon(couponCode: string): Promise<Cart> {
    const response = await apiRequest<ApiResponse<Cart>>({
      method: 'POST',
      url: `${ENDPOINTS.CART.BASE}/coupon`,
      data: { code: couponCode },
    });
    
    return response.data;
  }

  // Remove coupon from cart
  async removeCoupon(): Promise<Cart> {
    const response = await apiRequest<ApiResponse<Cart>>({
      method: 'DELETE',
      url: `${ENDPOINTS.CART.BASE}/coupon`,
    });
    
    return response.data;
  }

  // Get cart item count
  async getCartItemCount(): Promise<number> {
    try {
      const cart = await this.getCart();
      return cart.totalItems;
    } catch (error) {
      return 0;
    }
  }

  // Check if product is in cart
  async isProductInCart(productId: string, variantId?: string): Promise<boolean> {
    try {
      const cart = await this.getCart();
      return cart.items.some(item => 
        item.product._id === productId && 
        (!variantId || item.variant?._id === variantId)
      );
    } catch (error) {
      return false;
    }
  }

  // Sync local cart with server (useful for guest to user conversion)
  async syncCart(localCartItems: AddToCartRequest[]): Promise<Cart> {
    const response = await apiRequest<ApiResponse<Cart>>({
      method: 'POST',
      url: `${ENDPOINTS.CART.BASE}/sync`,
      data: { items: localCartItems },
    });
    
    return response.data;
  }

  // Get cart summary for checkout
  async getCartSummary(): Promise<{
    subtotal: number;
    tax: number;
    shipping: number;
    total: number;
    itemCount: number;
  }> {
    const response = await apiRequest<ApiResponse<{
      subtotal: number;
      tax: number;
      shipping: number;
      total: number;
      itemCount: number;
    }>>({
      method: 'GET',
      url: `${ENDPOINTS.CART.BASE}/summary`,
    });
    
    return response.data;
  }
}

export default new CartService();