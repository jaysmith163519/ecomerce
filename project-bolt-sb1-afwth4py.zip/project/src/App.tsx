import { useState, StrictMode } from 'react';
import Header from './components/Header';
import Homepage from './components/Homepage';
import ProductCatalog from './components/ProductCatalog';
import ProductDetail from './components/ProductDetail';
import Cart from './components/Cart';
import Checkout from './components/Checkout';
import OrderConfirmation from './components/OrderConfirmation';
import UserAccount from './components/UserAccount';
import About from './components/About';
import Contact from './components/Contact';
import Careers from './components/Careers';
import Press from './components/Press';
import Blog from './components/Blog';
import HelpCenter from './components/HelpCenter';
import ShippingInfo from './components/ShippingInfo';
import Returns from './components/Returns';
import SizeGuide from './components/SizeGuide';
import TrackOrder from './components/TrackOrder';
import PrivacyPolicy from './components/PrivacyPolicy';
import TermsOfService from './components/TermsOfService';
import CookiePolicy from './components/CookiePolicy';
import Accessibility from './components/Accessibility';
import Footer from './components/Footer';
import AuthModal from './components/AuthModal';
import LoadingSpinner from './components/LoadingSpinner';
import ErrorBoundary from './components/ErrorBoundary';
import Breadcrumbs from './components/Breadcrumbs';
import { CartProvider } from './contexts/CartContext';
import { AuthProvider } from './contexts/AuthContext';
import { WishlistProvider } from './contexts/WishlistContext';

// Define types
interface Product {
  id: string;
  name: string;
  price: number;
  image: string;
  category: string;
  rating: number;
  reviews: number;
  inStock: boolean;
}

interface OrderData {
  id: string;
  items: any[];
  total: number;
  shippingAddress: any;
  orderDate: string;
  estimatedDelivery: string;
}

function App(): JSX.Element {
  const [currentPage, setCurrentPage] = useState<string>('home');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [orderData, setOrderData] = useState<OrderData | null>(null);
  const [showAuthModal, setShowAuthModal] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  const navigateToProduct = (product: Product): void => {
    setIsLoading(true);
    setTimeout(() => {
      setSelectedProduct(product);
      setCurrentPage('product-detail');
      setIsLoading(false);
    }, 300);
  };

  const navigateToPage = (page: string): void => {
    setIsLoading(true);
    setTimeout(() => {
      setCurrentPage(page);
      setSelectedProduct(null);
      setIsLoading(false);
      window.scrollTo(0, 0);
    }, 200);
  };

  const handleOrderComplete = (order: OrderData): void => {
    setOrderData(order);
    setCurrentPage('order-confirmation');
  };

  const getBreadcrumbs = () => {
    const breadcrumbs = [{ name: 'Home', page: 'home' }];
    
    switch (currentPage) {
      case 'products':
        breadcrumbs.push({ name: 'Products', page: 'products' });
        break;
      case 'product-detail':
        breadcrumbs.push({ name: 'Products', page: 'products' });
        breadcrumbs.push({ name: selectedProduct?.name || 'Product', page: 'product-detail' });
        break;
      case 'cart':
        breadcrumbs.push({ name: 'Shopping Cart', page: 'cart' });
        break;
      case 'checkout':
        breadcrumbs.push({ name: 'Shopping Cart', page: 'cart' });
        breadcrumbs.push({ name: 'Checkout', page: 'checkout' });
        break;
      case 'account':
        breadcrumbs.push({ name: 'My Account', page: 'account' });
        break;
      case 'about':
        breadcrumbs.push({ name: 'About Us', page: 'about' });
        break;
      case 'contact':
        breadcrumbs.push({ name: 'Contact', page: 'contact' });
        break;
      default:
        if (currentPage !== 'home') {
          breadcrumbs.push({ name: currentPage.charAt(0).toUpperCase() + currentPage.slice(1), page: currentPage });
        }
    }
    
    return breadcrumbs;
  };

  return (
    <StrictMode>
      <ErrorBoundary>
        <AuthProvider>
          <CartProvider>
            <WishlistProvider>
              <div className="min-h-screen bg-gray-50 flex flex-col">
                <Header
                  onNavigate={navigateToPage}
                  onShowAuth={() => setShowAuthModal(true)}
                  currentPage={currentPage}
                  searchQuery={searchQuery}
                  onSearchChange={setSearchQuery}
                />

                {currentPage !== 'home' && (
                  <Breadcrumbs 
                    breadcrumbs={getBreadcrumbs()} 
                    onNavigate={navigateToPage} 
                  />
                )}

                <main className="flex-grow" role="main">
                  {isLoading ? (
                    <LoadingSpinner />
                  ) : (
                    <>
                      {currentPage === 'home' && (
                        <Homepage
                          onNavigate={navigateToPage}
                          onProductClick={navigateToProduct}
                        />
                      )}

                      {currentPage === 'products' && (
                        <ProductCatalog 
                          onProductClick={navigateToProduct}
                          searchQuery={searchQuery}
                        />
                      )}

                      {currentPage === 'product-detail' && selectedProduct && (
                        <ProductDetail
                          product={selectedProduct}
                          onBack={() => navigateToPage('products')}
                        />
                      )}

                      {currentPage === 'cart' && (
                        <Cart
                          onNavigate={navigateToPage}
                          onCheckout={() => navigateToPage('checkout')}
                        />
                      )}

                      {currentPage === 'checkout' && (
                        <Checkout
                          onBack={() => navigateToPage('cart')}
                          onOrderComplete={handleOrderComplete}
                        />
                      )}

                      {currentPage === 'order-confirmation' && orderData && (
                        <OrderConfirmation
                          order={orderData}
                          onContinueShopping={() => navigateToPage('home')}
                        />
                      )}

                      {currentPage === 'account' && (
                        <UserAccount onNavigate={navigateToPage} />
                      )}

                      {currentPage === 'about' && <About />}
                      {currentPage === 'contact' && <Contact />}
                      {currentPage === 'careers' && <Careers />}
                      {currentPage === 'press' && <Press />}
                      {currentPage === 'blog' && <Blog onNavigate={navigateToPage} />}
                      {currentPage === 'help' && <HelpCenter onNavigate={navigateToPage} />}
                      {currentPage === 'shipping' && <ShippingInfo />}
                      {currentPage === 'returns' && <Returns />}
                      {currentPage === 'size-guide' && <SizeGuide />}
                      {currentPage === 'track' && <TrackOrder />}
                      {currentPage === 'privacy' && <PrivacyPolicy />}
                      {currentPage === 'terms' && <TermsOfService />}
                      {currentPage === 'cookies' && <CookiePolicy />}
                      {currentPage === 'accessibility' && <Accessibility />}
                    </>
                  )}
                </main>

                <Footer onNavigate={navigateToPage} />

                {showAuthModal && (
                  <AuthModal onClose={() => setShowAuthModal(false)} />
                )}
              </div>
            </WishlistProvider>
          </CartProvider>
        </AuthProvider>
      </ErrorBoundary>
    </StrictMode>
  );
}

export default App;