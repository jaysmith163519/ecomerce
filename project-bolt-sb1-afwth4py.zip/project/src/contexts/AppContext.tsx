import React, { createContext, useContext, ReactNode } from 'react';
import { useAuth } from '../hooks/useAuth';
import { useCart } from '../hooks/useCart';
import { useToast } from '../hooks/useToast';
import { ToastContainer } from '../components/ui/Toast';

interface AppContextType {
  auth: ReturnType<typeof useAuth>;
  cart: ReturnType<typeof useCart>;
  toast: ReturnType<typeof useToast>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};

interface AppProviderProps {
  children: ReactNode;
}

export const AppProvider: React.FC<AppProviderProps> = ({ children }) => {
  const auth = useAuth();
  const cart = useCart();
  const toast = useToast();

  const value: AppContextType = {
    auth,
    cart,
    toast,
  };

  return (
    <AppContext.Provider value={value}>
      {children}
      <ToastContainer 
        toasts={toast.toasts} 
        onClose={toast.removeToast}
        position="top-right"
      />
    </AppContext.Provider>
  );
};