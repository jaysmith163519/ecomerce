import React from 'react';
import { Eye, Ear, Hand, Brain, Monitor, Keyboard, Mouse, Smartphone } from 'lucide-react';

const Accessibility: React.FC = () => {
  const accessibilityFeatures = [
    {
      category: 'Visual Accessibility',
      icon: Eye,
      color: 'blue',
      features: [
        'High contrast color schemes available',
        'Scalable text up to 200% without horizontal scrolling',
        'Alternative text for all images and graphics',
        'Clear visual focus indicators for keyboard navigation',
        'Consistent navigation and layout structure',
        'Color is not the only way to convey information'
      ]
    },
    {
      category: 'Hearing Accessibility',
      icon: Ear,
      color: 'green',
      features: [
        'Captions available for all video content',
        'Visual alerts and notifications',
        'Text alternatives for audio content',
        'Sign language interpretation for key videos',
        'Volume controls for all audio elements',
        'No auto-playing audio content'
      ]
    },
    {
      category: 'Motor Accessibility',
      icon: Hand,
      color: 'purple',
      features: [
        'Full keyboard navigation support',
        'Large click targets (minimum 44x44 pixels)',
        'No time limits on form completion',
        'Drag and drop alternatives available',
        'Voice control compatibility',
        'Switch navigation support'
      ]
    },
    {
      category: 'Cognitive Accessibility',
      icon: Brain,
      color: 'orange',
      features: [
        'Clear and simple language throughout',
        'Consistent navigation and terminology',
        'Error messages with clear instructions',
        'Progress indicators for multi-step processes',
        'Option to extend session timeouts',
        'Breadcrumb navigation for orientation'
      ]
    }
  ];

  const assistiveTechnologies = [
    {
      name: 'Screen Readers',
      icon: Monitor,
      description: 'Compatible with JAWS, NVDA, VoiceOver, and TalkBack',
      support: 'Full support with semantic HTML and ARIA labels'
    },
    {
      name: 'Keyboard Navigation',
      icon: Keyboard,
      description: 'Complete website functionality without a mouse',
      support: 'Tab order, skip links, and keyboard shortcuts available'
    },
    {
      name: 'Voice Control',
      icon: Mouse,
      description: 'Dragon NaturallySpeaking and Voice Control compatibility',
      support: 'Voice commands for navigation and form completion'
    },
    {
      name: 'Mobile Accessibility',
      icon: Smartphone,
      description: 'Touch gestures and mobile screen reader support',
      support: 'Optimized for iOS VoiceOver and Android TalkBack'
    }
  ];

  const wcagCompliance = [
    {
      level: 'WCAG 2.1 Level AA',
      status: 'Compliant',
      description: 'We meet or exceed Web Content Accessibility Guidelines 2.1 Level AA standards',
      details: [
        'Perceivable: Information presented in ways users can perceive',
        'Operable: Interface components are operable by all users',
        'Understandable: Information and UI operation is understandable',
        'Robust: Content works with various assistive technologies'
      ]
    }
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-purple-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">Accessibility Statement</h1>
          <p className="text-xl md:text-2xl text-blue-100 max-w-3xl mx-auto">
            We're committed to ensuring our website is accessible to everyone, regardless of ability or technology.
          </p>
        </div>
      </section>

      {/* Commitment */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Commitment</h2>
            <p className="text-lg text-gray-600 leading-relaxed">
              ShopEase is committed to ensuring digital accessibility for people with disabilities. We continually 
              improve the user experience for everyone and apply relevant accessibility standards to ensure we 
              provide equal access to information and functionality.
            </p>
          </div>
          
          <div className="bg-blue-50 rounded-lg p-8">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Accessibility Goals</h3>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium text-gray-900 mb-2">Universal Design</h4>
                <p className="text-gray-600 text-sm">
                  We design our website to be usable by as many people as possible, without the need for specialized adaptations.
                </p>
              </div>
              <div>
                <h4 className="font-medium text-gray-900 mb-2">Continuous Improvement</h4>
                <p className="text-gray-600 text-sm">
                  We regularly test our website with assistive technologies and gather feedback from users with disabilities.
                </p>
              </div>
              <div>
                <h4 className="font-medium text-gray-900 mb-2">Standards Compliance</h4>
                <p className="text-gray-600 text-sm">
                  We follow WCAG 2.1 Level AA guidelines and other accessibility best practices in our development process.
                </p>
              </div>
              <div>
                <h4 className="font-medium text-gray-900 mb-2">Inclusive Experience</h4>
                <p className="text-gray-600 text-sm">
                  We strive to provide an equivalent experience for all users, regardless of their abilities or the technologies they use.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Accessibility Features */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Accessibility Features</h2>
            <p className="text-lg text-gray-600">How we make our website accessible to everyone</p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-8">
            {accessibilityFeatures.map((category, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md p-8">
                <div className="flex items-center mb-6">
                  <div className={`w-12 h-12 bg-${category.color}-100 rounded-lg flex items-center justify-center mr-4`}>
                    <category.icon className={`w-6 h-6 text-${category.color}-600`} />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900">{category.category}</h3>
                </div>
                
                <ul className="space-y-3">
                  {category.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start">
                      <div className={`w-2 h-2 bg-${category.color}-400 rounded-full mt-2 mr-3 flex-shrink-0`}></div>
                      <span className="text-gray-600">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Assistive Technology Support */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Assistive Technology Support</h2>
            <p className="text-lg text-gray-600">We test our website with various assistive technologies</p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {assistiveTechnologies.map((tech, index) => (
              <div key={index} className="bg-gray-50 rounded-lg p-6 text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <tech.icon className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">{tech.name}</h3>
                <p className="text-gray-600 text-sm mb-3">{tech.description}</p>
                <p className="text-blue-600 text-xs font-medium">{tech.support}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* WCAG Compliance */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Standards Compliance</h2>
            <p className="text-lg text-gray-600">Our commitment to accessibility standards</p>
          </div>
          
          {wcagCompliance.map((compliance, index) => (
            <div key={index} className="bg-white rounded-lg shadow-md p-8">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-semibold text-gray-900">{compliance.level}</h3>
                <span className="bg-green-100 text-green-800 px-4 py-2 rounded-full font-medium">
                  {compliance.status}
                </span>
              </div>
              
              <p className="text-gray-600 mb-6">{compliance.description}</p>
              
              <div className="grid md:grid-cols-2 gap-6">
                {compliance.details.map((detail, detailIndex) => (
                  <div key={detailIndex} className="flex items-start">
                    <div className="w-2 h-2 bg-green-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <span className="text-gray-600">{detail}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Keyboard Navigation */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Keyboard Navigation</h2>
            <p className="text-lg text-gray-600">Essential keyboard shortcuts for navigating our website</p>
          </div>
          
          <div className="bg-gray-50 rounded-lg p-8">
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Navigation Shortcuts</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Skip to main content</span>
                    <kbd className="bg-gray-200 px-2 py-1 rounded text-sm font-mono">Tab</kbd>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Navigate forward</span>
                    <kbd className="bg-gray-200 px-2 py-1 rounded text-sm font-mono">Tab</kbd>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Navigate backward</span>
                    <kbd className="bg-gray-200 px-2 py-1 rounded text-sm font-mono">Shift + Tab</kbd>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Activate element</span>
                    <kbd className="bg-gray-200 px-2 py-1 rounded text-sm font-mono">Enter / Space</kbd>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Form Controls</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Select dropdown</span>
                    <kbd className="bg-gray-200 px-2 py-1 rounded text-sm font-mono">Arrow Keys</kbd>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Check/uncheck box</span>
                    <kbd className="bg-gray-200 px-2 py-1 rounded text-sm font-mono">Space</kbd>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Submit form</span>
                    <kbd className="bg-gray-200 px-2 py-1 rounded text-sm font-mono">Enter</kbd>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Close modal</span>
                    <kbd className="bg-gray-200 px-2 py-1 rounded text-sm font-mono">Escape</kbd>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Known Issues */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Known Issues & Improvements</h2>
            <p className="text-lg text-gray-600">Areas we're actively working to improve</p>
          </div>
          
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Current Limitations</h3>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-amber-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <span>Some third-party embedded content may not be fully accessible</span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-amber-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <span>Complex data tables are being enhanced with better navigation</span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-amber-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <span>Some animations cannot be disabled (working on preference controls)</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Planned Improvements</h3>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-green-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <span>Enhanced voice navigation support (Q2 2024)</span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-green-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <span>Improved mobile accessibility features (Q2 2024)</span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-green-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <span>Additional language support for screen readers (Q3 2024)</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Feedback and Contact */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Accessibility Feedback</h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            We welcome your feedback on the accessibility of our website. Please let us know if you encounter 
            any accessibility barriers.
          </p>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <h3 className="font-semibold mb-2">Email</h3>
              <p className="text-blue-100">accessibility@shopease.com</p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Phone</h3>
              <p className="text-blue-100">1-800-ACCESS (1-800-222-3771)</p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Mail</h3>
              <p className="text-blue-100">
                Accessibility Team<br />
                ShopEase Inc.<br />
                123 Commerce St<br />
                New York, NY 10001
              </p>
            </div>
          </div>
          
          <div className="mt-8 bg-white bg-opacity-10 rounded-lg p-6">
            <h3 className="text-lg font-semibold mb-3">Response Time</h3>
            <p className="text-blue-100">
              We aim to respond to accessibility feedback within 2 business days and will work with you 
              to resolve any issues as quickly as possible.
            </p>
          </div>
        </div>
      </section>

      {/* Legal Information */}
      <section className="py-8 bg-gray-100">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-gray-600 text-sm">
            <strong>Legal Compliance:</strong> This accessibility statement was last reviewed on January 15, 2024. 
            We are committed to maintaining compliance with applicable accessibility laws and regulations, 
            including the Americans with Disabilities Act (ADA) and Section 508 of the Rehabilitation Act.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Accessibility;