import React, { useState } from 'react';
import { Ruler, User, Shirt, Package } from 'lucide-react';

const SizeGuide: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState('clothing');

  const categories = [
    { id: 'clothing', name: 'Clothing', icon: Shirt },
    { id: 'shoes', name: 'Shoes', icon: Package },
    { id: 'accessories', name: 'Accessories', icon: User }
  ];

  const clothingSizes = {
    women: [
      { size: 'XS', chest: '32-34', waist: '24-26', hips: '34-36' },
      { size: 'S', chest: '34-36', waist: '26-28', hips: '36-38' },
      { size: 'M', chest: '36-38', waist: '28-30', hips: '38-40' },
      { size: 'L', chest: '38-40', waist: '30-32', hips: '40-42' },
      { size: 'XL', chest: '40-42', waist: '32-34', hips: '42-44' },
      { size: 'XXL', chest: '42-44', waist: '34-36', hips: '44-46' }
    ],
    men: [
      { size: 'XS', chest: '34-36', waist: '28-30', neck: '14-14.5' },
      { size: 'S', chest: '36-38', waist: '30-32', neck: '15-15.5' },
      { size: 'M', chest: '38-40', waist: '32-34', neck: '16-16.5' },
      { size: 'L', chest: '40-42', waist: '34-36', neck: '17-17.5' },
      { size: 'XL', chest: '42-44', waist: '36-38', neck: '18-18.5' },
      { size: 'XXL', chest: '44-46', waist: '38-40', neck: '19-19.5' }
    ]
  };

  const shoeSizes = {
    women: [
      { us: '5', uk: '2.5', eu: '35', cm: '22' },
      { us: '5.5', uk: '3', eu: '35.5', cm: '22.5' },
      { us: '6', uk: '3.5', eu: '36', cm: '23' },
      { us: '6.5', uk: '4', eu: '37', cm: '23.5' },
      { us: '7', uk: '4.5', eu: '37.5', cm: '24' },
      { us: '7.5', uk: '5', eu: '38', cm: '24.5' },
      { us: '8', uk: '5.5', eu: '39', cm: '25' },
      { us: '8.5', uk: '6', eu: '39.5', cm: '25.5' },
      { us: '9', uk: '6.5', eu: '40', cm: '26' },
      { us: '9.5', uk: '7', eu: '41', cm: '26.5' },
      { us: '10', uk: '7.5', eu: '41.5', cm: '27' }
    ],
    men: [
      { us: '6', uk: '5.5', eu: '39', cm: '24' },
      { us: '6.5', uk: '6', eu: '39.5', cm: '24.5' },
      { us: '7', uk: '6.5', eu: '40', cm: '25' },
      { us: '7.5', uk: '7', eu: '40.5', cm: '25.5' },
      { us: '8', uk: '7.5', eu: '41', cm: '26' },
      { us: '8.5', uk: '8', eu: '42', cm: '26.5' },
      { us: '9', uk: '8.5', eu: '42.5', cm: '27' },
      { us: '9.5', uk: '9', eu: '43', cm: '27.5' },
      { us: '10', uk: '9.5', eu: '44', cm: '28' },
      { us: '10.5', uk: '10', eu: '44.5', cm: '28.5' },
      { us: '11', uk: '10.5', eu: '45', cm: '29' },
      { us: '12', uk: '11.5', eu: '46', cm: '30' }
    ]
  };

  const measurementTips = [
    {
      title: 'Chest/Bust',
      description: 'Measure around the fullest part of your chest, keeping the tape parallel to the floor.'
    },
    {
      title: 'Waist',
      description: 'Measure around your natural waistline, which is the narrowest part of your torso.'
    },
    {
      title: 'Hips',
      description: 'Measure around the fullest part of your hips, about 7-9 inches below your waist.'
    },
    {
      title: 'Inseam',
      description: 'Measure from the crotch seam to the bottom of the leg along the inside seam.'
    }
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-purple-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">Size Guide</h1>
          <p className="text-xl md:text-2xl text-blue-100 max-w-3xl mx-auto">
            Find your perfect fit with our comprehensive sizing charts and measurement guide.
          </p>
        </div>
      </section>

      {/* Category Selection */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Select Category</h2>
            <p className="text-lg text-gray-600">Choose the type of product you're shopping for</p>
          </div>
          
          <div className="flex justify-center">
            <div className="flex space-x-4 bg-gray-100 rounded-lg p-2">
              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`flex items-center space-x-2 px-6 py-3 rounded-lg transition-colors duration-200 ${
                    selectedCategory === category.id
                      ? 'bg-blue-600 text-white'
                      : 'text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  <category.icon className="w-5 h-5" />
                  <span className="font-medium">{category.name}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Clothing Sizes */}
      {selectedCategory === 'clothing' && (
        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Clothing Size Charts</h2>
              <p className="text-lg text-gray-600">All measurements are in inches</p>
            </div>
            
            <div className="grid lg:grid-cols-2 gap-12">
              {/* Women's Sizes */}
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="bg-pink-50 px-6 py-4 border-b">
                  <h3 className="text-xl font-semibold text-gray-900">Women's Sizes</h3>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Size</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Chest</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Waist</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Hips</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {clothingSizes.women.map((size, index) => (
                        <tr key={index} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap font-medium text-gray-900">{size.size}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-gray-600">{size.chest}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-gray-600">{size.waist}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-gray-600">{size.hips}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Men's Sizes */}
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="bg-blue-50 px-6 py-4 border-b">
                  <h3 className="text-xl font-semibold text-gray-900">Men's Sizes</h3>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Size</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Chest</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Waist</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Neck</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {clothingSizes.men.map((size, index) => (
                        <tr key={index} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap font-medium text-gray-900">{size.size}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-gray-600">{size.chest}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-gray-600">{size.waist}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-gray-600">{size.neck}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Shoe Sizes */}
      {selectedCategory === 'shoes' && (
        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Shoe Size Charts</h2>
              <p className="text-lg text-gray-600">International size conversions</p>
            </div>
            
            <div className="grid lg:grid-cols-2 gap-12">
              {/* Women's Shoe Sizes */}
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="bg-pink-50 px-6 py-4 border-b">
                  <h3 className="text-xl font-semibold text-gray-900">Women's Shoe Sizes</h3>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">US</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">UK</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">EU</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">CM</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {shoeSizes.women.map((size, index) => (
                        <tr key={index} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap font-medium text-gray-900">{size.us}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-gray-600">{size.uk}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-gray-600">{size.eu}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-gray-600">{size.cm}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Men's Shoe Sizes */}
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="bg-blue-50 px-6 py-4 border-b">
                  <h3 className="text-xl font-semibold text-gray-900">Men's Shoe Sizes</h3>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">US</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">UK</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">EU</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">CM</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {shoeSizes.men.map((size, index) => (
                        <tr key={index} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap font-medium text-gray-900">{size.us}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-gray-600">{size.uk}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-gray-600">{size.eu}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-gray-600">{size.cm}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Accessories */}
      {selectedCategory === 'accessories' && (
        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Accessories Size Guide</h2>
              <p className="text-lg text-gray-600">Sizing information for accessories</p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {/* Ring Sizes */}
              <div className="bg-white rounded-lg shadow-md p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Ring Sizes</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Size 5</span>
                    <span>15.7 mm</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Size 6</span>
                    <span>16.5 mm</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Size 7</span>
                    <span>17.3 mm</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Size 8</span>
                    <span>18.1 mm</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Size 9</span>
                    <span>19.0 mm</span>
                  </div>
                </div>
              </div>

              {/* Belt Sizes */}
              <div className="bg-white rounded-lg shadow-md p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Belt Sizes</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>XS</span>
                    <span>28-30"</span>
                  </div>
                  <div className="flex justify-between">
                    <span>S</span>
                    <span>30-32"</span>
                  </div>
                  <div className="flex justify-between">
                    <span>M</span>
                    <span>32-34"</span>
                  </div>
                  <div className="flex justify-between">
                    <span>L</span>
                    <span>34-36"</span>
                  </div>
                  <div className="flex justify-between">
                    <span>XL</span>
                    <span>36-38"</span>
                  </div>
                </div>
              </div>

              {/* Hat Sizes */}
              <div className="bg-white rounded-lg shadow-md p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Hat Sizes</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>S</span>
                    <span>21.5-22"</span>
                  </div>
                  <div className="flex justify-between">
                    <span>M</span>
                    <span>22-22.5"</span>
                  </div>
                  <div className="flex justify-between">
                    <span>L</span>
                    <span>22.5-23"</span>
                  </div>
                  <div className="flex justify-between">
                    <span>XL</span>
                    <span>23-23.5"</span>
                  </div>
                  <div className="flex justify-between">
                    <span>XXL</span>
                    <span>23.5-24"</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Measurement Guide */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">How to Measure</h2>
            <p className="text-lg text-gray-600">Follow these tips for accurate measurements</p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {measurementTips.map((tip, index) => (
              <div key={index} className="bg-gray-50 rounded-lg p-6 text-center">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Ruler className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">{tip.title}</h3>
                <p className="text-gray-600 text-sm">{tip.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Fit Tips */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Fit Tips</h2>
            <p className="text-lg text-gray-600">Additional guidance for the perfect fit</p>
          </div>
          
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Between Sizes?</h3>
              <p className="text-gray-600">
                If you're between sizes, we generally recommend sizing up for a more comfortable fit. 
                Check the product description for specific fit recommendations.
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Different Brands, Different Fits</h3>
              <p className="text-gray-600">
                Sizing can vary between brands and styles. Always check the specific size chart for 
                each product and read customer reviews for fit insights.
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Still Unsure?</h3>
              <p className="text-gray-600">
                Our customer service team is here to help! Contact us with your measurements and 
                we'll recommend the best size for you. Remember, we offer free returns and exchanges.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default SizeGuide;