import React from 'react';
import { CheckCircle, Package, Truck, Calendar, Download, ArrowRight } from 'lucide-react';

interface OrderConfirmationProps {
  order: any;
  onContinueShopping: () => void;
}

const OrderConfirmation: React.FC<OrderConfirmationProps> = ({ order, onContinueShopping }) => {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div className="text-center mb-12">
        <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle className="w-12 h-12 text-green-600" />
        </div>
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Order Confirmed!</h1>
        <p className="text-lg text-gray-600 mb-2">
          Thank you for your purchase. Your order has been successfully placed.
        </p>
        <p className="text-gray-600">
          Order #{order.id} • Placed on {formatDate(order.orderDate)}
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8 mb-12">
        {/* Order Details */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold mb-6 flex items-center">
            <Package className="w-5 h-5 mr-2" />
            Order Details
          </h2>
          
          <div className="space-y-4">
            {order.items.map((item: any) => (
              <div key={item.id} className="flex items-center space-x-4">
                <img 
                  src={item.image}
                  alt={item.name}
                  className="w-16 h-16 object-cover rounded-lg"
                />
                <div className="flex-1">
                  <h3 className="font-medium text-gray-900">{item.name}</h3>
                  <p className="text-gray-600">Quantity: {item.quantity}</p>
                </div>
                <div className="text-right">
                  <p className="font-medium">${(item.price * item.quantity).toFixed(2)}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="border-t mt-6 pt-6">
            <div className="flex justify-between text-lg font-semibold">
              <span>Total</span>
              <span>${order.total.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Shipping Information */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold mb-6 flex items-center">
            <Truck className="w-5 h-5 mr-2" />
            Shipping Information
          </h2>
          
          <div className="space-y-4">
            <div>
              <h3 className="font-medium text-gray-900 mb-2">Delivery Address</h3>
              <div className="text-gray-600">
                <p>{order.shippingAddress.firstName} {order.shippingAddress.lastName}</p>
                <p>{order.shippingAddress.address}</p>
                <p>{order.shippingAddress.city}, {order.shippingAddress.state} {order.shippingAddress.zipCode}</p>
                <p>{order.shippingAddress.country}</p>
              </div>
            </div>

            <div>
              <h3 className="font-medium text-gray-900 mb-2">Estimated Delivery</h3>
              <div className="flex items-center text-gray-600">
                <Calendar className="w-4 h-4 mr-2" />
                <span>{formatDate(order.estimatedDelivery)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Order Status Timeline */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-xl font-semibold mb-6">Order Status</h2>
        
        <div className="flex items-center justify-between">
          <div className="flex flex-col items-center">
            <div className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center mb-2">
              <CheckCircle className="w-6 h-6 text-white" />
            </div>
            <span className="text-sm font-medium text-green-600">Order Placed</span>
            <span className="text-xs text-gray-500">Just now</span>
          </div>
          
          <div className="flex-1 h-0.5 bg-gray-200 mx-4"></div>
          
          <div className="flex flex-col items-center">
            <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center mb-2">
              <Package className="w-6 h-6 text-gray-400" />
            </div>
            <span className="text-sm font-medium text-gray-400">Processing</span>
            <span className="text-xs text-gray-500">1-2 days</span>
          </div>
          
          <div className="flex-1 h-0.5 bg-gray-200 mx-4"></div>
          
          <div className="flex flex-col items-center">
            <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center mb-2">
              <Truck className="w-6 h-6 text-gray-400" />
            </div>
            <span className="text-sm font-medium text-gray-400">Shipped</span>
            <span className="text-xs text-gray-500">3-5 days</span>
          </div>
          
          <div className="flex-1 h-0.5 bg-gray-200 mx-4"></div>
          
          <div className="flex flex-col items-center">
            <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center mb-2">
              <CheckCircle className="w-6 h-6 text-gray-400" />
            </div>
            <span className="text-sm font-medium text-gray-400">Delivered</span>
            <span className="text-xs text-gray-500">{formatDate(order.estimatedDelivery)}</span>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex flex-col sm:flex-row gap-4 justify-center">
        <button className="flex items-center justify-center px-6 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors duration-200">
          <Download className="w-4 h-4 mr-2" />
          Download Receipt
        </button>
        
        <button 
          onClick={onContinueShopping}
          className="flex items-center justify-center px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200"
        >
          Continue Shopping
          <ArrowRight className="w-4 h-4 ml-2" />
        </button>
      </div>

      {/* Help Section */}
      <div className="mt-12 text-center">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Need Help?</h3>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button className="text-blue-600 hover:text-blue-700 font-medium">
            Track Your Order
          </button>
          <button className="text-blue-600 hover:text-blue-700 font-medium">
            Contact Support
          </button>
          <button className="text-blue-600 hover:text-blue-700 font-medium">
            Return Policy
          </button>
        </div>
      </div>
    </div>
  );
};

export default OrderConfirmation;