import React from 'react';
import { Shield, Eye, Lock, Users, Globe, Mail } from 'lucide-react';

const PrivacyPolicy: React.FC = () => {
  const sections = [
    {
      title: 'Information We Collect',
      icon: Eye,
      content: [
        'Personal information you provide (name, email, address, phone number)',
        'Payment information (processed securely through encrypted payment processors)',
        'Account information (username, password, preferences)',
        'Order history and purchase information',
        'Device and browser information',
        'Website usage data and analytics',
        'Location information (with your consent)',
        'Customer service communications'
      ]
    },
    {
      title: 'How We Use Your Information',
      icon: Users,
      content: [
        'Process and fulfill your orders',
        'Provide customer service and support',
        'Send order confirmations and shipping updates',
        'Improve our products and services',
        'Personalize your shopping experience',
        'Send marketing communications (with your consent)',
        'Prevent fraud and ensure security',
        'Comply with legal obligations'
      ]
    },
    {
      title: 'Information Sharing',
      icon: Globe,
      content: [
        'We do not sell your personal information to third parties',
        'Service providers who help us operate our business',
        'Payment processors for transaction processing',
        'Shipping companies for order fulfillment',
        'Analytics providers to improve our services',
        'Legal authorities when required by law',
        'Business partners for joint marketing (with your consent)',
        'In case of business merger or acquisition'
      ]
    },
    {
      title: 'Data Security',
      icon: Lock,
      content: [
        'Industry-standard encryption for data transmission',
        'Secure servers with regular security updates',
        'Limited access to personal information',
        'Regular security audits and assessments',
        'Employee training on data protection',
        'Secure payment processing (PCI DSS compliant)',
        'Data backup and recovery procedures',
        'Incident response and notification procedures'
      ]
    }
  ];

  const lastUpdated = 'January 15, 2024';

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-purple-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">Privacy Policy</h1>
          <p className="text-xl md:text-2xl text-blue-100 max-w-3xl mx-auto">
            Your privacy is important to us. Learn how we collect, use, and protect your information.
          </p>
          <p className="text-blue-200 mt-4">Last updated: {lastUpdated}</p>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Shield className="w-8 h-8 text-blue-600" />
            </div>
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Commitment to Privacy</h2>
            <p className="text-lg text-gray-600 leading-relaxed">
              At ShopEase, we are committed to protecting your privacy and ensuring the security of your personal information. 
              This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our 
              website or use our services.
            </p>
          </div>
          
          <div className="bg-blue-50 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Key Principles</h3>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start">
                <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                <span>We only collect information necessary to provide our services</span>
              </li>
              <li className="flex items-start">
                <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                <span>We never sell your personal information to third parties</span>
              </li>
              <li className="flex items-start">
                <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                <span>We use industry-standard security measures to protect your data</span>
              </li>
              <li className="flex items-start">
                <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                <span>You have control over your personal information and privacy settings</span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* Main Sections */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-8">
            {sections.map((section, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md p-8">
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
                    <section.icon className="w-6 h-6 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900">{section.title}</h3>
                </div>
                
                <ul className="space-y-3">
                  {section.content.map((item, itemIndex) => (
                    <li key={itemIndex} className="flex items-start">
                      <div className="w-2 h-2 bg-gray-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                      <span className="text-gray-600">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Your Rights */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Your Privacy Rights</h2>
            <p className="text-lg text-gray-600">You have several rights regarding your personal information</p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div className="border-l-4 border-blue-600 pl-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Access Your Data</h3>
                <p className="text-gray-600">Request a copy of the personal information we have about you.</p>
              </div>
              
              <div className="border-l-4 border-green-600 pl-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Correct Your Data</h3>
                <p className="text-gray-600">Update or correct any inaccurate personal information.</p>
              </div>
              
              <div className="border-l-4 border-purple-600 pl-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Delete Your Data</h3>
                <p className="text-gray-600">Request deletion of your personal information (subject to legal requirements).</p>
              </div>
            </div>
            
            <div className="space-y-6">
              <div className="border-l-4 border-yellow-600 pl-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Opt-Out of Marketing</h3>
                <p className="text-gray-600">Unsubscribe from marketing communications at any time.</p>
              </div>
              
              <div className="border-l-4 border-red-600 pl-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Data Portability</h3>
                <p className="text-gray-600">Request your data in a portable format to transfer to another service.</p>
              </div>
              
              <div className="border-l-4 border-indigo-600 pl-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Restrict Processing</h3>
                <p className="text-gray-600">Limit how we use your personal information in certain circumstances.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Cookies and Tracking */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Cookies and Tracking</h2>
            <p className="text-lg text-gray-600">How we use cookies and similar technologies</p>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-8">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Essential Cookies</h3>
                <p className="text-gray-600">
                  Required for the website to function properly, including shopping cart functionality, 
                  user authentication, and security features.
                </p>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Analytics Cookies</h3>
                <p className="text-gray-600">
                  Help us understand how visitors interact with our website by collecting and 
                  reporting information anonymously.
                </p>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Marketing Cookies</h3>
                <p className="text-gray-600">
                  Used to deliver personalized advertisements and track the effectiveness of 
                  our marketing campaigns.
                </p>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Preference Cookies</h3>
                <p className="text-gray-600">
                  Remember your preferences and settings to provide a more personalized experience.
                </p>
              </div>
            </div>
            
            <div className="mt-8 p-4 bg-blue-50 rounded-lg">
              <p className="text-blue-800 text-sm">
                <strong>Cookie Control:</strong> You can manage your cookie preferences through your browser settings 
                or our cookie preference center. Note that disabling certain cookies may affect website functionality.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* International Transfers */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">International Data Transfers</h2>
            <p className="text-lg text-gray-600">How we handle data across borders</p>
          </div>
          
          <div className="bg-gray-50 rounded-lg p-8">
            <p className="text-gray-700 mb-6">
              ShopEase operates globally and may transfer your personal information to countries other than 
              your own. We ensure that all international transfers are protected by appropriate safeguards:
            </p>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Adequacy Decisions</h3>
                <p className="text-gray-600 text-sm">
                  We transfer data to countries recognized as providing adequate protection for personal data.
                </p>
              </div>
              
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Standard Contractual Clauses</h3>
                <p className="text-gray-600 text-sm">
                  We use EU-approved standard contractual clauses for transfers to countries without adequacy decisions.
                </p>
              </div>
              
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Certification Programs</h3>
                <p className="text-gray-600 text-sm">
                  Our service providers participate in recognized certification programs for data protection.
                </p>
              </div>
              
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Binding Corporate Rules</h3>
                <p className="text-gray-600 text-sm">
                  We maintain internal policies that ensure consistent data protection across all our operations.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Data Retention */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Data Retention</h2>
            <p className="text-lg text-gray-600">How long we keep your information</p>
          </div>
          
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Account Information</h3>
              <p className="text-gray-600">
                We retain your account information for as long as your account is active or as needed to provide services. 
                After account deletion, we may retain certain information for legal compliance.
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Transaction Records</h3>
              <p className="text-gray-600">
                Purchase history and transaction records are retained for 7 years for tax and accounting purposes, 
                or as required by applicable law.
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Marketing Data</h3>
              <p className="text-gray-600">
                Marketing preferences and communication history are retained until you opt out or for 3 years 
                after your last interaction with us.
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Website Analytics</h3>
              <p className="text-gray-600">
                Anonymous website usage data is typically retained for 26 months to help us improve our services 
                and understand user behavior patterns.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-6">
            <Mail className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-3xl font-bold mb-4">Questions About Privacy?</h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            If you have any questions about this Privacy Policy or our data practices, please contact us.
          </p>
          
          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div>
              <h3 className="font-semibold mb-2">Email</h3>
              <p className="text-blue-100">privacy@shopease.com</p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Phone</h3>
              <p className="text-blue-100">1-800-PRIVACY</p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Mail</h3>
              <p className="text-blue-100">
                Privacy Officer<br />
                ShopEase Inc.<br />
                123 Commerce St<br />
                New York, NY 10001
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Updates Notice */}
      <section className="py-8 bg-gray-100">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-gray-600">
            <strong>Policy Updates:</strong> We may update this Privacy Policy from time to time. 
            We will notify you of any material changes by email or through a prominent notice on our website.
          </p>
        </div>
      </section>
    </div>
  );
};

export default PrivacyPolicy;