import React from 'react';
import { ChevronRight, Home } from 'lucide-react';

interface Breadcrumb {
  name: string;
  page: string;
}

interface BreadcrumbsProps {
  breadcrumbs: Breadcrumb[];
  onNavigate: (page: string) => void;
}

const Breadcrumbs: React.FC<BreadcrumbsProps> = ({ breadcrumbs, onNavigate }) => {
  return (
    <nav className="bg-white border-b border-gray-200" aria-label="Breadcrumb">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <ol className="flex items-center space-x-2 py-3 text-sm">
          {breadcrumbs.map((breadcrumb, index) => (
            <li key={breadcrumb.page} className="flex items-center">
              {index > 0 && (
                <ChevronRight className="w-4 h-4 text-gray-400 mx-2" />
              )}
              {index === 0 ? (
                <button
                  onClick={() => onNavigate(breadcrumb.page)}
                  className="flex items-center text-gray-500 hover:text-blue-600 transition-colors duration-200"
                  aria-label="Go to homepage"
                >
                  <Home className="w-4 h-4 mr-1" />
                  <span className="sr-only">Home</span>
                </button>
              ) : index === breadcrumbs.length - 1 ? (
                <span className="text-gray-900 font-medium" aria-current="page">
                  {breadcrumb.name}
                </span>
              ) : (
                <button
                  onClick={() => onNavigate(breadcrumb.page)}
                  className="text-gray-500 hover:text-blue-600 transition-colors duration-200"
                >
                  {breadcrumb.name}
                </button>
              )}
            </li>
          ))}
        </ol>
      </div>
    </nav>
  );
};

export default Breadcrumbs;