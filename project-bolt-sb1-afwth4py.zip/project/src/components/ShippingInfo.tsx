import React from 'react';
import { Truck, Clock, MapPin, Package, Shield, DollarSign } from 'lucide-react';

const ShippingInfo: React.FC = () => {
  const shippingOptions = [
    {
      name: 'Standard Shipping',
      price: '$5.99',
      time: '5-7 business days',
      description: 'Reliable delivery for everyday orders',
      icon: Truck
    },
    {
      name: 'Express Shipping',
      price: '$15.99',
      time: '2-3 business days',
      description: 'Faster delivery when you need it sooner',
      icon: Clock
    },
    {
      name: 'Overnight Shipping',
      price: '$29.99',
      time: '1 business day',
      description: 'Next-day delivery for urgent orders',
      icon: Package
    },
    {
      name: 'Free Shipping',
      price: 'Free',
      time: '5-7 business days',
      description: 'On orders over $50',
      icon: DollarSign
    }
  ];

  const internationalShipping = [
    { country: 'Canada', time: '7-10 business days', cost: '$12.99' },
    { country: 'United Kingdom', time: '10-14 business days', cost: '$19.99' },
    { country: 'European Union', time: '10-14 business days', cost: '$24.99' },
    { country: 'Australia', time: '14-21 business days', cost: '$29.99' },
    { country: 'Japan', time: '10-14 business days', cost: '$24.99' },
    { country: 'Other Countries', time: '14-28 business days', cost: 'Varies' }
  ];

  const shippingPolicies = [
    {
      title: 'Processing Time',
      description: 'Orders are processed within 1-2 business days. Orders placed on weekends or holidays will be processed the next business day.'
    },
    {
      title: 'Shipping Confirmation',
      description: 'You\'ll receive a shipping confirmation email with tracking information once your order ships.'
    },
    {
      title: 'Address Accuracy',
      description: 'Please ensure your shipping address is correct. We cannot be responsible for packages sent to incorrect addresses.'
    },
    {
      title: 'Delivery Attempts',
      description: 'If delivery is unsuccessful, the carrier will make additional attempts or leave the package at a secure location.'
    }
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-purple-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">Shipping Information</h1>
          <p className="text-xl md:text-2xl text-blue-100 max-w-3xl mx-auto">
            Fast, reliable shipping options to get your orders to you quickly and safely.
          </p>
        </div>
      </section>

      {/* Shipping Options */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Shipping Options</h2>
            <p className="text-lg text-gray-600">Choose the shipping method that works best for you</p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {shippingOptions.map((option, index) => (
              <div key={index} className="bg-white border-2 border-gray-200 rounded-lg p-6 text-center hover:border-blue-300 transition-colors duration-200">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <option.icon className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{option.name}</h3>
                <div className="text-2xl font-bold text-blue-600 mb-2">{option.price}</div>
                <div className="text-gray-600 font-medium mb-3">{option.time}</div>
                <p className="text-gray-600 text-sm">{option.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Shipping Zones */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Shipping Zones</h2>
            <p className="text-lg text-gray-600">We ship to customers worldwide</p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Domestic Shipping */}
            <div className="bg-white rounded-lg shadow-md p-8">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mr-4">
                  <MapPin className="w-6 h-6 text-green-600" />
                </div>
                <h3 className="text-2xl font-semibold text-gray-900">Domestic Shipping (US)</h3>
              </div>
              
              <div className="space-y-4">
                <div className="flex justify-between items-center py-3 border-b border-gray-200">
                  <span className="font-medium">Free Shipping</span>
                  <span className="text-gray-600">Orders over $50</span>
                </div>
                <div className="flex justify-between items-center py-3 border-b border-gray-200">
                  <span className="font-medium">Standard Shipping</span>
                  <span className="text-gray-600">$5.99 (5-7 days)</span>
                </div>
                <div className="flex justify-between items-center py-3 border-b border-gray-200">
                  <span className="font-medium">Express Shipping</span>
                  <span className="text-gray-600">$15.99 (2-3 days)</span>
                </div>
                <div className="flex justify-between items-center py-3">
                  <span className="font-medium">Overnight Shipping</span>
                  <span className="text-gray-600">$29.99 (1 day)</span>
                </div>
              </div>
            </div>

            {/* International Shipping */}
            <div className="bg-white rounded-lg shadow-md p-8">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
                  <MapPin className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="text-2xl font-semibold text-gray-900">International Shipping</h3>
              </div>
              
              <div className="space-y-4">
                {internationalShipping.map((location, index) => (
                  <div key={index} className="flex justify-between items-center py-3 border-b border-gray-200 last:border-b-0">
                    <div>
                      <div className="font-medium">{location.country}</div>
                      <div className="text-sm text-gray-600">{location.time}</div>
                    </div>
                    <span className="text-gray-600 font-medium">{location.cost}</span>
                  </div>
                ))}
              </div>
              
              <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                <p className="text-sm text-blue-800">
                  <strong>Note:</strong> International orders may be subject to customs duties and taxes, 
                  which are the responsibility of the customer.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Shipping Policies */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Shipping Policies</h2>
            <p className="text-lg text-gray-600">Important information about our shipping process</p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            {shippingPolicies.map((policy, index) => (
              <div key={index} className="bg-gray-50 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">{policy.title}</h3>
                <p className="text-gray-600">{policy.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Special Shipping Info */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="bg-white rounded-lg shadow-md p-6 text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Secure Packaging</h3>
              <p className="text-gray-600">All orders are carefully packaged to ensure safe delivery</p>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6 text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Package className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Order Tracking</h3>
              <p className="text-gray-600">Track your package every step of the way with real-time updates</p>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6 text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Fast Processing</h3>
              <p className="text-gray-600">Orders placed before 2 PM EST ship the same business day</p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Shipping FAQ</h2>
            <p className="text-lg text-gray-600">Common questions about shipping</p>
          </div>
          
          <div className="space-y-6">
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Can I change my shipping address after placing an order?</h3>
              <p className="text-gray-600">
                You can change your shipping address within 1 hour of placing your order. After that, 
                please contact customer service as soon as possible, and we'll do our best to help.
              </p>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Do you ship to P.O. boxes?</h3>
              <p className="text-gray-600">
                Yes, we ship to P.O. boxes within the United States using USPS. However, express 
                and overnight shipping options are not available for P.O. box addresses.
              </p>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">What happens if my package is lost or damaged?</h3>
              <p className="text-gray-600">
                If your package is lost or arrives damaged, please contact us immediately. We'll work 
                with the shipping carrier to resolve the issue and ensure you receive your order.
              </p>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Can I expedite shipping on an existing order?</h3>
              <p className="text-gray-600">
                If your order hasn't shipped yet, you may be able to upgrade to faster shipping. 
                Contact customer service as soon as possible to check if this option is available.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ShippingInfo;