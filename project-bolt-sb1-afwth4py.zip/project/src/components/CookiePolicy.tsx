import React, { useState } from 'react';
import { Cookie, Settings, Eye, BarChart, Target, Shield } from 'lucide-react';

const CookiePolicy: React.FC = () => {
  const [cookiePreferences, setCookiePreferences] = useState({
    essential: true,
    analytics: true,
    marketing: false,
    preferences: true
  });

  const lastUpdated = 'January 15, 2024';

  const cookieTypes = [
    {
      id: 'essential',
      name: 'Essential Cookies',
      icon: Shield,
      description: 'Required for the website to function properly',
      purpose: 'These cookies are necessary for the website to function and cannot be switched off in our systems.',
      examples: [
        'User authentication and login status',
        'Shopping cart contents and checkout process',
        'Security and fraud prevention',
        'Website functionality and navigation',
        'Load balancing and performance optimization'
      ],
      required: true,
      color: 'red'
    },
    {
      id: 'analytics',
      name: 'Analytics Cookies',
      icon: BarChart,
      description: 'Help us understand how visitors use our website',
      purpose: 'These cookies allow us to count visits and traffic sources so we can measure and improve the performance of our site.',
      examples: [
        'Google Analytics for website traffic analysis',
        'Page view and session duration tracking',
        'User behavior and interaction patterns',
        'Popular content and search terms',
        'Website performance and error monitoring'
      ],
      required: false,
      color: 'blue'
    },
    {
      id: 'marketing',
      name: 'Marketing Cookies',
      icon: Target,
      description: 'Used to deliver personalized advertisements',
      purpose: 'These cookies are used to make advertising messages more relevant to you and your interests.',
      examples: [
        'Facebook Pixel for social media advertising',
        'Google Ads conversion tracking',
        'Retargeting and remarketing campaigns',
        'Personalized product recommendations',
        'Cross-platform advertising optimization'
      ],
      required: false,
      color: 'green'
    },
    {
      id: 'preferences',
      name: 'Preference Cookies',
      icon: Settings,
      description: 'Remember your preferences and settings',
      purpose: 'These cookies enable the website to provide enhanced functionality and personalization.',
      examples: [
        'Language and region preferences',
        'Theme and display settings',
        'Recently viewed products',
        'Saved filters and search preferences',
        'Accessibility settings and options'
      ],
      required: false,
      color: 'purple'
    }
  ];

  const handlePreferenceChange = (cookieId: string, enabled: boolean) => {
    setCookiePreferences(prev => ({
      ...prev,
      [cookieId]: enabled
    }));
  };

  const savePreferences = () => {
    // In a real application, this would save preferences to localStorage or send to server
    alert('Cookie preferences saved successfully!');
  };

  const acceptAll = () => {
    setCookiePreferences({
      essential: true,
      analytics: true,
      marketing: true,
      preferences: true
    });
  };

  const rejectAll = () => {
    setCookiePreferences({
      essential: true, // Essential cookies cannot be disabled
      analytics: false,
      marketing: false,
      preferences: false
    });
  };

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-purple-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">Cookie Policy</h1>
          <p className="text-xl md:text-2xl text-blue-100 max-w-3xl mx-auto">
            Learn about how we use cookies and similar technologies to improve your experience.
          </p>
          <p className="text-blue-200 mt-4">Last updated: {lastUpdated}</p>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Cookie className="w-8 h-8 text-blue-600" />
            </div>
            <h2 className="text-3xl font-bold text-gray-900 mb-4">What Are Cookies?</h2>
            <p className="text-lg text-gray-600 leading-relaxed">
              Cookies are small text files that are placed on your computer or mobile device when you visit a website. 
              They are widely used to make websites work more efficiently and provide information to website owners.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-blue-50 rounded-lg p-6">
              <div className="flex items-center mb-4">
                <Eye className="w-6 h-6 text-blue-600 mr-3" />
                <h3 className="text-lg font-semibold text-gray-900">First-Party Cookies</h3>
              </div>
              <p className="text-gray-600">
                Set directly by our website and can only be read by our domain. These help us provide 
                core functionality and improve your user experience.
              </p>
            </div>
            
            <div className="bg-green-50 rounded-lg p-6">
              <div className="flex items-center mb-4">
                <Target className="w-6 h-6 text-green-600 mr-3" />
                <h3 className="text-lg font-semibold text-gray-900">Third-Party Cookies</h3>
              </div>
              <p className="text-gray-600">
                Set by external services we use, such as analytics providers or advertising networks. 
                These help us understand usage patterns and deliver relevant content.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Cookie Types */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Types of Cookies We Use</h2>
            <p className="text-lg text-gray-600">We use different types of cookies for various purposes</p>
          </div>
          
          <div className="space-y-8">
            {cookieTypes.map((cookieType) => (
              <div key={cookieType.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="p-8">
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center">
                      <div className={`w-12 h-12 bg-${cookieType.color}-100 rounded-lg flex items-center justify-center mr-4`}>
                        <cookieType.icon className={`w-6 h-6 text-${cookieType.color}-600`} />
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold text-gray-900">{cookieType.name}</h3>
                        <p className="text-gray-600">{cookieType.description}</p>
                      </div>
                    </div>
                    
                    {cookieType.required ? (
                      <span className="bg-red-100 text-red-800 px-3 py-1 rounded-full text-sm font-medium">
                        Required
                      </span>
                    ) : (
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={cookiePreferences[cookieType.id as keyof typeof cookiePreferences]}
                          onChange={(e) => handlePreferenceChange(cookieType.id, e.target.checked)}
                          className="sr-only peer"
                        />
                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                      </label>
                    )}
                  </div>
                  
                  <p className="text-gray-600 mb-6">{cookieType.purpose}</p>
                  
                  <div>
                    <h4 className="font-medium text-gray-900 mb-3">Examples:</h4>
                    <ul className="grid md:grid-cols-2 gap-2">
                      {cookieType.examples.map((example, index) => (
                        <li key={index} className="flex items-start">
                          <div className={`w-2 h-2 bg-${cookieType.color}-400 rounded-full mt-2 mr-3 flex-shrink-0`}></div>
                          <span className="text-gray-600 text-sm">{example}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Cookie Management */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Manage Your Cookie Preferences</h2>
            <p className="text-lg text-gray-600">You have control over which cookies we use</p>
          </div>
          
          <div className="bg-gray-50 rounded-lg p-8">
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
              <button
                onClick={acceptAll}
                className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors duration-200 font-medium"
              >
                Accept All Cookies
              </button>
              <button
                onClick={rejectAll}
                className="bg-gray-600 text-white px-6 py-3 rounded-lg hover:bg-gray-700 transition-colors duration-200 font-medium"
              >
                Reject Non-Essential
              </button>
              <button
                onClick={savePreferences}
                className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors duration-200 font-medium"
              >
                Save Preferences
              </button>
            </div>
            
            <div className="text-center">
              <p className="text-gray-600 text-sm mb-4">
                Your current preferences will be saved and applied to your browsing experience.
              </p>
              <p className="text-gray-500 text-xs">
                Note: Disabling certain cookies may affect website functionality and your user experience.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Browser Controls */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Browser Cookie Controls</h2>
            <p className="text-lg text-gray-600">How to manage cookies in your browser</p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Desktop Browsers</h3>
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium text-gray-900">Chrome</h4>
                  <p className="text-gray-600 text-sm">Settings → Privacy and security → Cookies and other site data</p>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900">Firefox</h4>
                  <p className="text-gray-600 text-sm">Options → Privacy & Security → Cookies and Site Data</p>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900">Safari</h4>
                  <p className="text-gray-600 text-sm">Preferences → Privacy → Manage Website Data</p>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900">Edge</h4>
                  <p className="text-gray-600 text-sm">Settings → Cookies and site permissions → Cookies and site data</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Mobile Browsers</h3>
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium text-gray-900">Chrome Mobile</h4>
                  <p className="text-gray-600 text-sm">Menu → Settings → Site settings → Cookies</p>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900">Safari Mobile</h4>
                  <p className="text-gray-600 text-sm">Settings → Safari → Block All Cookies</p>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900">Firefox Mobile</h4>
                  <p className="text-gray-600 text-sm">Menu → Settings → Data Management → Cookies</p>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900">Samsung Internet</h4>
                  <p className="text-gray-600 text-sm">Menu → Settings → Sites and downloads → Cookies</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-8 bg-amber-50 border border-amber-200 rounded-lg p-6">
            <div className="flex items-start">
              <Settings className="w-6 h-6 text-amber-600 mr-3 mt-1 flex-shrink-0" />
              <div>
                <h3 className="text-lg font-semibold text-amber-800 mb-2">Important Note</h3>
                <p className="text-amber-700">
                  Blocking or deleting cookies may impact your experience on our website. Some features may not 
                  work properly, and you may need to re-enter information or preferences.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Third-Party Services */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Third-Party Services</h2>
            <p className="text-lg text-gray-600">External services we use and their cookie policies</p>
          </div>
          
          <div className="space-y-6">
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Google Analytics</h3>
              <p className="text-gray-600 mb-3">
                We use Google Analytics to understand how visitors interact with our website. 
                Google Analytics uses cookies to collect information anonymously.
              </p>
              <a href="https://policies.google.com/privacy" target="_blank" rel="noopener noreferrer" 
                 className="text-blue-600 hover:text-blue-700 font-medium text-sm">
                View Google's Privacy Policy →
              </a>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Facebook Pixel</h3>
              <p className="text-gray-600 mb-3">
                We use Facebook Pixel to measure the effectiveness of our advertising and provide 
                personalized ads on Facebook and Instagram.
              </p>
              <a href="https://www.facebook.com/privacy/explanation" target="_blank" rel="noopener noreferrer" 
                 className="text-blue-600 hover:text-blue-700 font-medium text-sm">
                View Facebook's Privacy Policy →
              </a>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Payment Processors</h3>
              <p className="text-gray-600 mb-3">
                Our payment processors (Stripe, PayPal) use cookies to ensure secure transactions 
                and prevent fraud during the checkout process.
              </p>
              <div className="flex space-x-4">
                <a href="https://stripe.com/privacy" target="_blank" rel="noopener noreferrer" 
                   className="text-blue-600 hover:text-blue-700 font-medium text-sm">
                  Stripe Privacy Policy →
                </a>
                <a href="https://www.paypal.com/privacy" target="_blank" rel="noopener noreferrer" 
                   className="text-blue-600 hover:text-blue-700 font-medium text-sm">
                  PayPal Privacy Policy →
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Updates and Contact */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Questions About Cookies?</h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            If you have any questions about our use of cookies, please contact us.
          </p>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <h3 className="font-semibold mb-2">Email</h3>
              <p className="text-blue-100">privacy@shopease.com</p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Phone</h3>
              <p className="text-blue-100">1-800-SHOPEASE</p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Live Chat</h3>
              <p className="text-blue-100">Available 24/7</p>
            </div>
          </div>
        </div>
      </section>

      {/* Policy Updates */}
      <section className="py-8 bg-gray-100">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-gray-600">
            <strong>Policy Updates:</strong> We may update this Cookie Policy from time to time. 
            We will notify you of any material changes by posting the new policy on this page.
          </p>
        </div>
      </section>
    </div>
  );
};

export default CookiePolicy;