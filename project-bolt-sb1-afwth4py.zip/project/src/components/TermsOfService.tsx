import React from 'react';
import { FileText, Scale, Shield, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';

const TermsOfService: React.FC = () => {
  const lastUpdated = 'January 15, 2024';

  const sections = [
    {
      title: 'Account Terms',
      icon: Shield,
      content: [
        'You must be 18 years or older to create an account',
        'You are responsible for maintaining account security',
        'One person or legal entity may maintain only one account',
        'You must provide accurate and complete information',
        'You are responsible for all activity under your account',
        'We reserve the right to suspend or terminate accounts',
        'Account termination does not affect existing orders',
        'You must notify us of any unauthorized account use'
      ]
    },
    {
      title: 'Acceptable Use',
      icon: CheckCircle,
      content: [
        'Use our services only for lawful purposes',
        'Do not violate any applicable laws or regulations',
        'Respect intellectual property rights',
        'Do not interfere with our services or systems',
        'Do not attempt to gain unauthorized access',
        'Do not use automated systems without permission',
        'Do not post harmful or offensive content',
        'Comply with all posted guidelines and policies'
      ]
    },
    {
      title: 'Prohibited Activities',
      icon: XCircle,
      content: [
        'Fraudulent or deceptive practices',
        'Harassment or abuse of other users',
        'Spamming or unsolicited communications',
        'Distributing malware or viruses',
        'Attempting to hack or breach security',
        'Reselling our services without permission',
        'Creating fake accounts or impersonation',
        'Any activity that violates applicable laws'
      ]
    },
    {
      title: 'Liability & Disclaimers',
      icon: AlertTriangle,
      content: [
        'Services provided "as is" without warranties',
        'We disclaim all implied warranties',
        'Limitation of liability to maximum extent allowed',
        'No liability for indirect or consequential damages',
        'User assumes risk of service interruptions',
        'Third-party content and links not our responsibility',
        'Force majeure events beyond our control',
        'Some jurisdictions may not allow these limitations'
      ]
    }
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-purple-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">Terms of Service</h1>
          <p className="text-xl md:text-2xl text-blue-100 max-w-3xl mx-auto">
            Please read these terms carefully before using our services.
          </p>
          <p className="text-blue-200 mt-4">Last updated: {lastUpdated}</p>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <FileText className="w-8 h-8 text-blue-600" />
            </div>
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Agreement to Terms</h2>
            <p className="text-lg text-gray-600 leading-relaxed">
              By accessing and using ShopEase's website and services, you accept and agree to be bound by the terms 
              and provision of this agreement. If you do not agree to abide by the above, please do not use this service.
            </p>
          </div>
          
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-6">
            <div className="flex items-start">
              <AlertTriangle className="w-6 h-6 text-amber-600 mr-3 mt-1 flex-shrink-0" />
              <div>
                <h3 className="text-lg font-semibold text-amber-800 mb-2">Important Notice</h3>
                <p className="text-amber-700">
                  These terms constitute a legally binding agreement between you and ShopEase. Please read them carefully 
                  and contact us if you have any questions before using our services.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Terms Sections */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-8">
            {sections.map((section, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md p-8">
                <div className="flex items-center mb-6">
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center mr-4 ${
                    section.title === 'Prohibited Activities' ? 'bg-red-100' :
                    section.title === 'Liability & Disclaimers' ? 'bg-amber-100' :
                    section.title === 'Acceptable Use' ? 'bg-green-100' : 'bg-blue-100'
                  }`}>
                    <section.icon className={`w-6 h-6 ${
                      section.title === 'Prohibited Activities' ? 'text-red-600' :
                      section.title === 'Liability & Disclaimers' ? 'text-amber-600' :
                      section.title === 'Acceptable Use' ? 'text-green-600' : 'text-blue-600'
                    }`} />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900">{section.title}</h3>
                </div>
                
                <ul className="space-y-3">
                  {section.content.map((item, itemIndex) => (
                    <li key={itemIndex} className="flex items-start">
                      <div className={`w-2 h-2 rounded-full mt-2 mr-3 flex-shrink-0 ${
                        section.title === 'Prohibited Activities' ? 'bg-red-400' :
                        section.title === 'Liability & Disclaimers' ? 'bg-amber-400' :
                        section.title === 'Acceptable Use' ? 'bg-green-400' : 'bg-blue-400'
                      }`}></div>
                      <span className="text-gray-600">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Purchase Terms */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Purchase Terms</h2>
            <p className="text-lg text-gray-600">Terms specific to purchasing products and services</p>
          </div>
          
          <div className="space-y-8">
            <div className="bg-gray-50 rounded-lg p-8">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Pricing and Payment</h3>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Pricing</h4>
                  <ul className="space-y-1 text-gray-600 text-sm">
                    <li>• All prices are in USD unless otherwise stated</li>
                    <li>• Prices are subject to change without notice</li>
                    <li>• Promotional prices have limited validity</li>
                    <li>• Taxes and shipping costs are additional</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Payment</h4>
                  <ul className="space-y-1 text-gray-600 text-sm">
                    <li>• Payment is due at time of purchase</li>
                    <li>• We accept major credit cards and PayPal</li>
                    <li>• All transactions are processed securely</li>
                    <li>• Failed payments may result in order cancellation</li>
                  </ul>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-8">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Orders and Fulfillment</h3>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Order Processing</h4>
                  <ul className="space-y-1 text-gray-600 text-sm">
                    <li>• Orders are processed within 1-2 business days</li>
                    <li>• We reserve the right to cancel any order</li>
                    <li>• Order confirmation does not guarantee acceptance</li>
                    <li>• Bulk orders may require additional verification</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Shipping and Delivery</h4>
                  <ul className="space-y-1 text-gray-600 text-sm">
                    <li>• Delivery times are estimates, not guarantees</li>
                    <li>• Risk of loss transfers upon shipment</li>
                    <li>• Shipping addresses cannot be changed after processing</li>
                    <li>• Additional fees may apply for special delivery</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Intellectual Property */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Intellectual Property</h2>
            <p className="text-lg text-gray-600">Protection of intellectual property rights</p>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-8">
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Our Rights</h3>
                <ul className="space-y-3 text-gray-600">
                  <li className="flex items-start">
                    <Scale className="w-5 h-5 text-blue-600 mr-3 mt-0.5 flex-shrink-0" />
                    <span>All content on our website is protected by copyright</span>
                  </li>
                  <li className="flex items-start">
                    <Scale className="w-5 h-5 text-blue-600 mr-3 mt-0.5 flex-shrink-0" />
                    <span>Trademarks and logos are our exclusive property</span>
                  </li>
                  <li className="flex items-start">
                    <Scale className="w-5 h-5 text-blue-600 mr-3 mt-0.5 flex-shrink-0" />
                    <span>Software and technology are proprietary</span>
                  </li>
                  <li className="flex items-start">
                    <Scale className="w-5 h-5 text-blue-600 mr-3 mt-0.5 flex-shrink-0" />
                    <span>Unauthorized use is strictly prohibited</span>
                  </li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Your Rights</h3>
                <ul className="space-y-3 text-gray-600">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-green-600 mr-3 mt-0.5 flex-shrink-0" />
                    <span>Limited license to use our services</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-green-600 mr-3 mt-0.5 flex-shrink-0" />
                    <span>Personal, non-commercial use permitted</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-green-600 mr-3 mt-0.5 flex-shrink-0" />
                    <span>Right to access purchased content</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-green-600 mr-3 mt-0.5 flex-shrink-0" />
                    <span>Fair use rights as permitted by law</span>
                  </li>
                </ul>
              </div>
            </div>
            
            <div className="mt-8 p-4 bg-blue-50 rounded-lg">
              <p className="text-blue-800 text-sm">
                <strong>DMCA Notice:</strong> If you believe your intellectual property rights have been violated, 
                please contact us with a detailed notice including the specific content and your contact information.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Dispute Resolution */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Dispute Resolution</h2>
            <p className="text-lg text-gray-600">How we handle disputes and legal matters</p>
          </div>
          
          <div className="space-y-6">
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Governing Law</h3>
              <p className="text-gray-600">
                These terms are governed by the laws of the State of New York, without regard to conflict of law principles. 
                Any legal action must be brought in the courts of New York County, New York.
              </p>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Arbitration Agreement</h3>
              <p className="text-gray-600 mb-3">
                Most disputes can be resolved through our customer service team. For disputes that cannot be resolved 
                informally, you agree to binding arbitration rather than court proceedings.
              </p>
              <ul className="space-y-1 text-gray-600 text-sm">
                <li>• Arbitration will be conducted by the American Arbitration Association</li>
                <li>• Proceedings will be held in New York, NY or via video conference</li>
                <li>• Each party bears their own costs unless otherwise awarded</li>
                <li>• Class action lawsuits are waived</li>
              </ul>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Exceptions to Arbitration</h3>
              <p className="text-gray-600">
                The following disputes are not subject to arbitration: intellectual property disputes, 
                small claims court matters under $10,000, and injunctive relief requests.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Modifications and Termination */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Changes and Termination</h2>
            <p className="text-lg text-gray-600">How these terms may change and when they end</p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Modifications to Terms</h3>
              <ul className="space-y-3 text-gray-600">
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <span>We may update these terms at any time</span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <span>Material changes will be communicated via email</span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <span>Continued use constitutes acceptance</span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <span>You may terminate if you disagree</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Account Termination</h3>
              <ul className="space-y-3 text-gray-600">
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-red-600 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <span>You may close your account at any time</span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-red-600 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <span>We may suspend accounts for violations</span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-red-600 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <span>Termination doesn't affect existing orders</span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-red-600 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <span>Some provisions survive termination</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Questions About These Terms?</h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            If you have any questions about these Terms of Service, please contact our legal team.
          </p>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <h3 className="font-semibold mb-2">Email</h3>
              <p className="text-blue-100">legal@shopease.com</p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Phone</h3>
              <p className="text-blue-100">1-800-SHOPEASE</p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Mail</h3>
              <p className="text-blue-100">
                Legal Department<br />
                ShopEase Inc.<br />
                123 Commerce St<br />
                New York, NY 10001
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Effective Date */}
      <section className="py-8 bg-gray-100">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-gray-600">
            <strong>Effective Date:</strong> These Terms of Service are effective as of {lastUpdated} and 
            will remain in effect except with respect to any changes in their provisions in the future.
          </p>
        </div>
      </section>
    </div>
  );
};

export default TermsOfService;