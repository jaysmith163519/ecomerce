import React from 'react';

interface SkeletonLoaderProps {
  className?: string;
  variant?: 'text' | 'rectangular' | 'circular';
  width?: string | number;
  height?: string | number;
  lines?: number;
}

const SkeletonLoader: React.FC<SkeletonLoaderProps> = ({
  className = '',
  variant = 'rectangular',
  width,
  height,
  lines = 1,
}) => {
  const baseClasses = 'animate-pulse bg-gray-200 rounded';
  
  const variantClasses = {
    text: 'h-4 rounded',
    rectangular: 'rounded-lg',
    circular: 'rounded-full',
  };

  const style: React.CSSProperties = {};
  if (width) style.width = typeof width === 'number' ? `${width}px` : width;
  if (height) style.height = typeof height === 'number' ? `${height}px` : height;

  if (variant === 'text' && lines > 1) {
    return (
      <div className={`space-y-2 ${className}`}>
        {Array.from({ length: lines }).map((_, index) => (
          <div
            key={index}
            className={`${baseClasses} ${variantClasses[variant]} ${
              index === lines - 1 ? 'w-3/4' : 'w-full'
            }`}
            style={{ height: height || '1rem' }}
          />
        ))}
      </div>
    );
  }

  return (
    <div
      className={`${baseClasses} ${variantClasses[variant]} ${className}`}
      style={style}
    />
  );
};

// Predefined skeleton components
export const ProductCardSkeleton: React.FC = () => (
  <div className="bg-white rounded-lg shadow-md overflow-hidden">
    <SkeletonLoader variant="rectangular" height={200} />
    <div className="p-4 space-y-3">
      <SkeletonLoader variant="text" lines={2} />
      <div className="flex items-center justify-between">
        <SkeletonLoader variant="text" width={80} />
        <SkeletonLoader variant="text" width={60} />
      </div>
    </div>
  </div>
);

export const ProductDetailSkeleton: React.FC = () => (
  <div className="grid lg:grid-cols-2 gap-12">
    <div>
      <SkeletonLoader variant="rectangular" height={400} className="mb-4" />
      <div className="grid grid-cols-4 gap-2">
        {Array.from({ length: 4 }).map((_, index) => (
          <SkeletonLoader key={index} variant="rectangular" height={80} />
        ))}
      </div>
    </div>
    <div className="space-y-6">
      <SkeletonLoader variant="text" lines={3} />
      <SkeletonLoader variant="text" width={200} height={32} />
      <SkeletonLoader variant="text" lines={4} />
      <div className="flex space-x-4">
        <SkeletonLoader variant="rectangular" width={120} height={48} />
        <SkeletonLoader variant="rectangular" width={48} height={48} />
      </div>
    </div>
  </div>
);

export const CartItemSkeleton: React.FC = () => (
  <div className="flex items-center space-x-4 p-4 border-b">
    <SkeletonLoader variant="rectangular" width={80} height={80} />
    <div className="flex-1 space-y-2">
      <SkeletonLoader variant="text" lines={2} />
      <SkeletonLoader variant="text" width={100} />
    </div>
    <div className="space-y-2">
      <SkeletonLoader variant="rectangular" width={100} height={32} />
      <SkeletonLoader variant="text" width={80} />
    </div>
  </div>
);

export default SkeletonLoader;