import React, { useState } from 'react';
import { Search, Package, Truck, CheckCircle, MapPin, Clock, Phone, Mail } from 'lucide-react';

const TrackOrder: React.FC = () => {
  const [trackingNumber, setTrackingNumber] = useState('');
  const [orderData, setOrderData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Mock order data for demonstration
  const mockOrderData = {
    orderNumber: 'ORD-2024-001',
    trackingNumber: 'TRK123456789',
    status: 'In Transit',
    estimatedDelivery: '2024-01-20',
    currentLocation: 'Distribution Center - Chicago, IL',
    items: [
      {
        name: 'Smart Watch Series 5',
        image: 'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?auto=compress&cs=tinysrgb&w=200',
        quantity: 1,
        price: 199.99
      },
      {
        name: 'Wireless Headphones',
        image: 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=200',
        quantity: 1,
        price: 249.99
      }
    ],
    shippingAddress: {
      name: 'John Doe',
      address: '123 Main Street',
      city: 'New York',
      state: 'NY',
      zip: '10001'
    },
    timeline: [
      {
        status: 'Order Placed',
        date: '2024-01-15',
        time: '10:30 AM',
        location: 'Online',
        completed: true,
        description: 'Your order has been confirmed and is being prepared'
      },
      {
        status: 'Processing',
        date: '2024-01-16',
        time: '2:15 PM',
        location: 'Fulfillment Center - Newark, NJ',
        completed: true,
        description: 'Items are being picked and packed'
      },
      {
        status: 'Shipped',
        date: '2024-01-17',
        time: '8:45 AM',
        location: 'Fulfillment Center - Newark, NJ',
        completed: true,
        description: 'Package has been shipped and is on its way'
      },
      {
        status: 'In Transit',
        date: '2024-01-18',
        time: '11:20 AM',
        location: 'Distribution Center - Chicago, IL',
        completed: true,
        description: 'Package is in transit to your location',
        current: true
      },
      {
        status: 'Out for Delivery',
        date: '2024-01-20',
        time: 'Expected',
        location: 'Local Delivery Facility',
        completed: false,
        description: 'Package will be out for delivery'
      },
      {
        status: 'Delivered',
        date: '2024-01-20',
        time: 'Expected',
        location: 'Your Address',
        completed: false,
        description: 'Package will be delivered to your address'
      }
    ]
  };

  const handleTrackOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!trackingNumber.trim()) return;

    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      if (trackingNumber.toLowerCase().includes('trk') || trackingNumber.toLowerCase().includes('ord')) {
        setOrderData(mockOrderData);
      } else {
        setOrderData(null);
      }
      setIsLoading(false);
    }, 1000);
  };

  const getStatusIcon = (status: string, completed: boolean, current: boolean) => {
    if (current) {
      return <Truck className="w-6 h-6 text-blue-600" />;
    } else if (completed) {
      return <CheckCircle className="w-6 h-6 text-green-600" />;
    } else {
      return <div className="w-6 h-6 border-2 border-gray-300 rounded-full"></div>;
    }
  };

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-purple-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">Track Your Order</h1>
          <p className="text-xl md:text-2xl text-blue-100 max-w-3xl mx-auto">
            Enter your tracking number or order number to see real-time updates on your shipment.
          </p>
        </div>
      </section>

      {/* Tracking Form */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gray-50 rounded-lg p-8">
            <form onSubmit={handleTrackOrder} className="space-y-6">
              <div>
                <label htmlFor="trackingNumber" className="block text-lg font-medium text-gray-900 mb-4">
                  Enter Tracking Number or Order Number
                </label>
                <div className="relative">
                  <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-6 h-6" />
                  <input
                    type="text"
                    id="trackingNumber"
                    value={trackingNumber}
                    onChange={(e) => setTrackingNumber(e.target.value)}
                    placeholder="e.g., TRK123456789 or ORD-2024-001"
                    className="w-full pl-12 pr-4 py-4 border border-gray-300 rounded-lg text-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
              </div>
              
              <div className="text-center">
                <button
                  type="submit"
                  disabled={isLoading}
                  className="bg-blue-600 text-white px-8 py-4 rounded-lg hover:bg-blue-700 transition-colors duration-200 font-medium text-lg disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isLoading ? 'Tracking...' : 'Track Order'}
                </button>
              </div>
            </form>
            
            <div className="mt-6 text-center text-sm text-gray-600">
              <p>Don't have your tracking number? <a href="#" className="text-blue-600 hover:text-blue-700 font-medium">Check your email</a> or <a href="#" className="text-blue-600 hover:text-blue-700 font-medium">log into your account</a></p>
            </div>
          </div>
        </div>
      </section>

      {/* Order Results */}
      {orderData && (
        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Order Summary */}
            <div className="bg-white rounded-lg shadow-md p-8 mb-8">
              <div className="grid lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-bold text-gray-900">Order {orderData.orderNumber}</h2>
                    <span className={`px-4 py-2 rounded-full text-sm font-medium ${
                      orderData.status === 'Delivered' ? 'bg-green-100 text-green-800' :
                      orderData.status === 'In Transit' ? 'bg-blue-100 text-blue-800' :
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {orderData.status}
                    </span>
                  </div>
                  
                  <div className="grid md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <h3 className="font-medium text-gray-900 mb-2">Tracking Number</h3>
                      <p className="text-gray-600 font-mono">{orderData.trackingNumber}</p>
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900 mb-2">Estimated Delivery</h3>
                      <p className="text-gray-600">{new Date(orderData.estimatedDelivery).toLocaleDateString()}</p>
                    </div>
                  </div>
                  
                  <div className="mb-6">
                    <h3 className="font-medium text-gray-900 mb-2 flex items-center">
                      <MapPin className="w-4 h-4 mr-2" />
                      Current Location
                    </h3>
                    <p className="text-gray-600">{orderData.currentLocation}</p>
                  </div>
                </div>
                
                <div>
                  <h3 className="font-medium text-gray-900 mb-4">Shipping Address</h3>
                  <div className="text-gray-600">
                    <p>{orderData.shippingAddress.name}</p>
                    <p>{orderData.shippingAddress.address}</p>
                    <p>{orderData.shippingAddress.city}, {orderData.shippingAddress.state} {orderData.shippingAddress.zip}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Order Items */}
            <div className="bg-white rounded-lg shadow-md p-8 mb-8">
              <h3 className="text-xl font-semibold text-gray-900 mb-6">Order Items</h3>
              <div className="space-y-4">
                {orderData.items.map((item: any, index: number) => (
                  <div key={index} className="flex items-center space-x-4">
                    <img 
                      src={item.image}
                      alt={item.name}
                      className="w-16 h-16 object-cover rounded-lg"
                    />
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900">{item.name}</h4>
                      <p className="text-gray-600">Quantity: {item.quantity}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">${item.price.toFixed(2)}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Tracking Timeline */}
            <div className="bg-white rounded-lg shadow-md p-8">
              <h3 className="text-xl font-semibold text-gray-900 mb-8">Tracking Timeline</h3>
              
              <div className="space-y-8">
                {orderData.timeline.map((event: any, index: number) => (
                  <div key={index} className="flex items-start space-x-4">
                    <div className="flex-shrink-0">
                      {getStatusIcon(event.status, event.completed, event.current)}
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className={`font-medium ${
                          event.current ? 'text-blue-600' : 
                          event.completed ? 'text-gray-900' : 'text-gray-500'
                        }`}>
                          {event.status}
                        </h4>
                        <div className="text-sm text-gray-500">
                          {event.date} • {event.time}
                        </div>
                      </div>
                      
                      <p className={`text-sm mb-1 ${
                        event.current ? 'text-blue-600' : 
                        event.completed ? 'text-gray-600' : 'text-gray-400'
                      }`}>
                        {event.location}
                      </p>
                      
                      <p className={`text-sm ${
                        event.current ? 'text-blue-600' : 
                        event.completed ? 'text-gray-600' : 'text-gray-400'
                      }`}>
                        {event.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* No Results */}
      {trackingNumber && !isLoading && !orderData && (
        <section className="py-16 bg-gray-50">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="bg-white rounded-lg shadow-md p-12">
              <Package className="w-16 h-16 text-gray-300 mx-auto mb-6" />
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Order Not Found</h3>
              <p className="text-gray-600 mb-6">
                We couldn't find an order with that tracking number. Please check your number and try again.
              </p>
              <div className="space-y-2 text-sm text-gray-600">
                <p>• Make sure you entered the complete tracking number</p>
                <p>• Check your email for the correct tracking information</p>
                <p>• It may take up to 24 hours for tracking to become available</p>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Help Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Need Help?</h2>
            <p className="text-lg text-gray-600">Our customer service team is here to assist you</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Phone className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Call Us</h3>
              <p className="text-gray-600 mb-4">Speak with a customer service representative</p>
              <p className="text-blue-600 font-medium">1-800-SHOPEASE</p>
              <p className="text-sm text-gray-500">Mon-Fri 9AM-6PM EST</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Mail className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Email Support</h3>
              <p className="text-gray-600 mb-4">Send us a detailed message</p>
              <p className="text-green-600 font-medium">support@shopease.com</p>
              <p className="text-sm text-gray-500">Response within 24 hours</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Live Chat</h3>
              <p className="text-gray-600 mb-4">Get instant help from our team</p>
              <button className="text-purple-600 font-medium hover:text-purple-700">
                Start Chat
              </button>
              <p className="text-sm text-gray-500">Available 24/7</p>
            </div>
          </div>
        </div>
      </section>

      {/* Tracking Tips */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Tracking Tips</h2>
            <p className="text-lg text-gray-600">Get the most out of our tracking system</p>
          </div>
          
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Tracking Number Formats</h3>
              <p className="text-gray-600 mb-3">
                Our tracking numbers typically start with "TRK" followed by 9 digits (e.g., TRK123456789). 
                You can also use your order number (e.g., ORD-2024-001).
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Tracking Updates</h3>
              <p className="text-gray-600">
                Tracking information is updated in real-time as your package moves through our network. 
                Updates may take a few hours to appear after each scan.
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Delivery Notifications</h3>
              <p className="text-gray-600">
                You'll receive email and SMS notifications (if enabled) for key milestones including 
                shipment, out for delivery, and delivery confirmation.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default TrackOrder;