import React from 'react';
import { Calendar, ExternalLink, Download, Award, TrendingUp, Users } from 'lucide-react';

const Press: React.FC = () => {
  const pressReleases = [
    {
      id: 1,
      title: 'ShopEase Announces $50M Series B Funding Round',
      date: '2024-01-15',
      excerpt: 'Leading e-commerce platform secures major funding to accelerate global expansion and product development.',
      category: 'Funding',
      link: '#'
    },
    {
      id: 2,
      title: 'ShopEase Launches AI-Powered Personalization Engine',
      date: '2024-01-10',
      excerpt: 'Revolutionary technology delivers personalized shopping experiences, increasing customer satisfaction by 40%.',
      category: 'Product',
      link: '#'
    },
    {
      id: 3,
      title: 'ShopEase Reaches 10 Million Active Users Milestone',
      date: '2024-01-05',
      excerpt: 'Platform celebrates significant growth milestone with users across 25 countries worldwide.',
      category: 'Milestone',
      link: '#'
    },
    {
      id: 4,
      title: 'ShopEase Partners with Major Retail Brands',
      date: '2023-12-20',
      excerpt: 'Strategic partnerships with leading retailers expand product catalog and enhance customer choice.',
      category: 'Partnership',
      link: '#'
    },
    {
      id: 5,
      title: 'ShopEase Wins "Best E-commerce Platform" Award',
      date: '2023-12-15',
      excerpt: 'Industry recognition for innovation in user experience and customer satisfaction.',
      category: 'Award',
      link: '#'
    }
  ];

  const mediaKit = [
    {
      title: 'Company Logo Pack',
      description: 'High-resolution logos in various formats',
      type: 'ZIP',
      size: '2.5 MB'
    },
    {
      title: 'Brand Guidelines',
      description: 'Complete brand identity and usage guidelines',
      type: 'PDF',
      size: '1.8 MB'
    },
    {
      title: 'Executive Photos',
      description: 'Professional headshots of leadership team',
      type: 'ZIP',
      size: '5.2 MB'
    },
    {
      title: 'Product Screenshots',
      description: 'High-quality platform and app screenshots',
      type: 'ZIP',
      size: '8.1 MB'
    }
  ];

  const awards = [
    {
      year: '2024',
      title: 'Best E-commerce Innovation',
      organization: 'Tech Excellence Awards',
      description: 'Recognized for AI-powered personalization technology'
    },
    {
      year: '2023',
      title: 'Customer Choice Award',
      organization: 'E-commerce Association',
      description: 'Highest customer satisfaction rating in the industry'
    },
    {
      year: '2023',
      title: 'Fastest Growing Startup',
      organization: 'Business Innovation Awards',
      description: '300% year-over-year growth recognition'
    },
    {
      year: '2022',
      title: 'Best Mobile App Design',
      organization: 'UX Design Awards',
      description: 'Outstanding user experience and interface design'
    }
  ];

  const keyStats = [
    {
      icon: Users,
      stat: '10M+',
      label: 'Active Users',
      description: 'Growing customer base across 25 countries'
    },
    {
      icon: TrendingUp,
      stat: '300%',
      label: 'YoY Growth',
      description: 'Consistent year-over-year revenue growth'
    },
    {
      icon: Award,
      stat: '15+',
      label: 'Industry Awards',
      description: 'Recognition for innovation and excellence'
    }
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-purple-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">Press Center</h1>
            <p className="text-xl md:text-2xl text-blue-100 max-w-3xl mx-auto mb-8">
              Latest news, press releases, and media resources from ShopEase.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors duration-200">
                Download Media Kit
              </button>
              <button className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors duration-200">
                Contact Press Team
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Key Statistics */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">ShopEase by the Numbers</h2>
            <p className="text-lg text-gray-600">Key metrics that showcase our growth and impact</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {keyStats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <stat.icon className="w-8 h-8 text-blue-600" />
                </div>
                <div className="text-4xl font-bold text-gray-900 mb-2">{stat.stat}</div>
                <div className="text-lg font-semibold text-gray-900 mb-2">{stat.label}</div>
                <p className="text-gray-600">{stat.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Press Releases */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Latest Press Releases</h2>
            <p className="text-lg text-gray-600">Stay updated with our latest news and announcements</p>
          </div>
          
          <div className="space-y-6">
            {pressReleases.map((release) => (
              <div key={release.id} className="bg-white rounded-lg shadow-md p-6">
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
                  <div className="flex-1">
                    <div className="flex items-center mb-2">
                      <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm font-medium mr-3">
                        {release.category}
                      </span>
                      <div className="flex items-center text-gray-500 text-sm">
                        <Calendar className="w-4 h-4 mr-1" />
                        {new Date(release.date).toLocaleDateString()}
                      </div>
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-3">{release.title}</h3>
                    <p className="text-gray-600 mb-4">{release.excerpt}</p>
                  </div>
                  <div className="mt-4 lg:mt-0 lg:ml-6">
                    <button className="flex items-center text-blue-600 hover:text-blue-700 font-medium">
                      Read More
                      <ExternalLink className="w-4 h-4 ml-2" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Awards & Recognition */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Awards & Recognition</h2>
            <p className="text-lg text-gray-600">Industry recognition for our innovation and excellence</p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            {awards.map((award, index) => (
              <div key={index} className="flex items-start space-x-4 p-6 bg-gray-50 rounded-lg">
                <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <Award className="w-6 h-6 text-yellow-600" />
                </div>
                <div>
                  <div className="text-sm text-gray-500 mb-1">{award.year}</div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-1">{award.title}</h3>
                  <div className="text-blue-600 font-medium mb-2">{award.organization}</div>
                  <p className="text-gray-600">{award.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Media Kit */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Media Kit</h2>
            <p className="text-lg text-gray-600">Download our brand assets and media resources</p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {mediaKit.map((item, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md p-6 text-center">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Download className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{item.title}</h3>
                <p className="text-gray-600 text-sm mb-3">{item.description}</p>
                <div className="flex items-center justify-center space-x-2 text-sm text-gray-500 mb-4">
                  <span>{item.type}</span>
                  <span>•</span>
                  <span>{item.size}</span>
                </div>
                <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200 text-sm">
                  Download
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Press Contact */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">Press Inquiries</h2>
              <p className="text-blue-100 mb-6">
                For media inquiries, interview requests, or additional information, 
                please contact our press team. We're here to help with your story.
              </p>
              <div className="space-y-4">
                <div>
                  <div className="font-semibold">Sarah Johnson</div>
                  <div className="text-blue-100">Head of Communications</div>
                  <div className="text-blue-100">press@shopease.com</div>
                  <div className="text-blue-100">+1 (555) 123-4567</div>
                </div>
              </div>
            </div>
            <div className="bg-white bg-opacity-10 rounded-lg p-8">
              <h3 className="text-xl font-semibold mb-6">Quick Facts</h3>
              <div className="space-y-4 text-blue-100">
                <div>
                  <div className="font-medium text-white">Founded:</div>
                  <div>2014</div>
                </div>
                <div>
                  <div className="font-medium text-white">Headquarters:</div>
                  <div>New York, NY</div>
                </div>
                <div>
                  <div className="font-medium text-white">Employees:</div>
                  <div>500+</div>
                </div>
                <div>
                  <div className="font-medium text-white">Markets:</div>
                  <div>25 Countries</div>
                </div>
                <div>
                  <div className="font-medium text-white">CEO:</div>
                  <div>Sarah Johnson</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Press;