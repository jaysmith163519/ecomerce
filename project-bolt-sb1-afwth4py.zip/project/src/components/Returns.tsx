import React, { useState } from 'react';
import { RotateCcw, Package, Clock, DollarSign, CheckCircle, AlertCircle, ArrowRight } from 'lucide-react';

const Returns: React.FC = () => {
  const [orderNumber, setOrderNumber] = useState('');
  const [email, setEmail] = useState('');

  const returnProcess = [
    {
      step: 1,
      title: 'Initiate Return',
      description: 'Log into your account or use our return form to start the process',
      icon: Package
    },
    {
      step: 2,
      title: 'Print Label',
      description: 'Print the prepaid return shipping label we provide',
      icon: RotateCcw
    },
    {
      step: 3,
      title: 'Ship Item',
      description: 'Package the item securely and drop it off at any carrier location',
      icon: Package
    },
    {
      step: 4,
      title: 'Get Refund',
      description: 'Receive your refund within 5-7 business days after we receive the item',
      icon: DollarSign
    }
  ];

  const returnPolicies = [
    {
      title: '30-Day Return Window',
      description: 'Items can be returned within 30 days of delivery for a full refund',
      icon: Clock,
      color: 'blue'
    },
    {
      title: 'Original Condition',
      description: 'Items must be unused, unworn, and in original packaging with tags attached',
      icon: CheckCircle,
      color: 'green'
    },
    {
      title: 'Free Return Shipping',
      description: 'We provide prepaid return labels for all eligible returns',
      icon: RotateCcw,
      color: 'purple'
    },
    {
      title: 'Fast Refunds',
      description: 'Refunds are processed within 5-7 business days of receiving your return',
      icon: DollarSign,
      color: 'yellow'
    }
  ];

  const nonReturnableItems = [
    'Personalized or customized items',
    'Intimate apparel and swimwear',
    'Items marked as final sale',
    'Gift cards and digital products',
    'Perishable goods',
    'Items damaged by misuse'
  ];

  const handleReturnSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle return form submission
    alert('Return request submitted! Check your email for further instructions.');
  };

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-purple-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">Returns & Exchanges</h1>
          <p className="text-xl md:text-2xl text-blue-100 max-w-3xl mx-auto">
            Easy returns and exchanges with free shipping. Your satisfaction is our priority.
          </p>
        </div>
      </section>

      {/* Return Policies */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Return Policy</h2>
            <p className="text-lg text-gray-600">Simple, hassle-free returns that put you first</p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {returnPolicies.map((policy, index) => (
              <div key={index} className="bg-white border-2 border-gray-200 rounded-lg p-6 text-center hover:border-blue-300 transition-colors duration-200">
                <div className={`w-16 h-16 bg-${policy.color}-100 rounded-full flex items-center justify-center mx-auto mb-4`}>
                  <policy.icon className={`w-8 h-8 text-${policy.color}-600`} />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">{policy.title}</h3>
                <p className="text-gray-600">{policy.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Return Process */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">How to Return an Item</h2>
            <p className="text-lg text-gray-600">Follow these simple steps to return your purchase</p>
          </div>
          
          <div className="grid md:grid-cols-4 gap-8">
            {returnProcess.map((step, index) => (
              <div key={step.step} className="text-center">
                <div className="relative">
                  <div className="w-16 h-16 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-4 font-bold text-xl">
                    {step.step}
                  </div>
                  {index < returnProcess.length - 1 && (
                    <div className="hidden md:block absolute top-8 left-full w-full h-0.5 bg-gray-300 transform -translate-y-1/2"></div>
                  )}
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Return Form */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Start a Return</h2>
            <p className="text-lg text-gray-600">Enter your order information to begin the return process</p>
          </div>
          
          <div className="bg-gray-50 rounded-lg p-8">
            <form onSubmit={handleReturnSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="orderNumber" className="block text-sm font-medium text-gray-700 mb-2">
                    Order Number *
                  </label>
                  <input
                    type="text"
                    id="orderNumber"
                    value={orderNumber}
                    onChange={(e) => setOrderNumber(e.target.value)}
                    placeholder="e.g., ORD-2024-001"
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    id="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="your@email.com"
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
              
              <div className="text-center">
                <button
                  type="submit"
                  className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors duration-200 font-medium flex items-center mx-auto"
                >
                  Start Return Process
                  <ArrowRight className="w-4 h-4 ml-2" />
                </button>
              </div>
            </form>
            
            <div className="mt-6 text-center">
              <p className="text-gray-600 text-sm">
                Don't have your order number? <a href="#" className="text-blue-600 hover:text-blue-700 font-medium">Contact customer service</a>
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Non-Returnable Items */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Items That Cannot Be Returned</h2>
            <p className="text-lg text-gray-600">For health and safety reasons, some items cannot be returned</p>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-8">
            <div className="flex items-center mb-6">
              <AlertCircle className="w-6 h-6 text-amber-600 mr-3" />
              <h3 className="text-lg font-semibold text-gray-900">Non-Returnable Items</h3>
            </div>
            
            <div className="grid md:grid-cols-2 gap-4">
              {nonReturnableItems.map((item, index) => (
                <div key={index} className="flex items-center">
                  <div className="w-2 h-2 bg-amber-600 rounded-full mr-3"></div>
                  <span className="text-gray-700">{item}</span>
                </div>
              ))}
            </div>
            
            <div className="mt-6 p-4 bg-amber-50 rounded-lg">
              <p className="text-amber-800 text-sm">
                <strong>Note:</strong> If you received a damaged or defective item, please contact us immediately. 
                We'll provide a replacement or full refund regardless of the item type.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Exchanges */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Need an Exchange?</h2>
              <p className="text-lg text-gray-600 mb-6">
                Want a different size or color? We make exchanges easy and fast.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-green-600 mr-3 mt-1" />
                  <div>
                    <h4 className="font-medium text-gray-900">Free Exchange Shipping</h4>
                    <p className="text-gray-600 text-sm">We cover shipping costs for exchanges</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-green-600 mr-3 mt-1" />
                  <div>
                    <h4 className="font-medium text-gray-900">Same-Day Processing</h4>
                    <p className="text-gray-600 text-sm">Exchanges are processed the same day we receive your item</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-green-600 mr-3 mt-1" />
                  <div>
                    <h4 className="font-medium text-gray-900">Extended Exchange Window</h4>
                    <p className="text-gray-600 text-sm">45 days for exchanges vs. 30 days for returns</p>
                  </div>
                </div>
              </div>
              
              <button className="mt-6 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors duration-200 font-medium">
                Start an Exchange
              </button>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-8">
              <h3 className="text-xl font-semibold text-gray-900 mb-6">Exchange Process</h3>
              <div className="space-y-4">
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold mr-4">
                    1
                  </div>
                  <span className="text-gray-700">Select the item you want to exchange</span>
                </div>
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold mr-4">
                    2
                  </div>
                  <span className="text-gray-700">Choose your new size, color, or style</span>
                </div>
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold mr-4">
                    3
                  </div>
                  <span className="text-gray-700">Ship your original item back to us</span>
                </div>
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold mr-4">
                    4
                  </div>
                  <span className="text-gray-700">Receive your new item within 3-5 days</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Return FAQ</h2>
            <p className="text-lg text-gray-600">Common questions about returns and exchanges</p>
          </div>
          
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">How long do I have to return an item?</h3>
              <p className="text-gray-600">
                You have 30 days from the delivery date to return most items. Exchanges have a 45-day window.
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Do I need to pay for return shipping?</h3>
              <p className="text-gray-600">
                No, we provide free prepaid return labels for all eligible returns and exchanges.
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">When will I receive my refund?</h3>
              <p className="text-gray-600">
                Refunds are processed within 5-7 business days after we receive your returned item. 
                It may take an additional 3-5 business days for the refund to appear in your account.
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Can I return sale items?</h3>
              <p className="text-gray-600">
                Yes, sale items can be returned within the 30-day window unless marked as "final sale." 
                Final sale items cannot be returned or exchanged.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Returns;