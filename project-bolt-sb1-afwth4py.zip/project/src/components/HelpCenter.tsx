import React, { useState } from 'react';
import { Search, Book, MessageCircle, Phone, Mail, ChevronRight, HelpCircle, Truck, CreditCard, Shield, RotateCcw } from 'lucide-react';

interface HelpCenterProps {
  onNavigate: (page: string) => void;
}

const HelpCenter: React.FC<HelpCenterProps> = ({ onNavigate }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  const categories = [
    {
      id: 'orders',
      name: 'Orders & Shipping',
      icon: Truck,
      description: 'Track orders, shipping info, and delivery questions',
      color: 'blue'
    },
    {
      id: 'payments',
      name: 'Payments & Billing',
      icon: CreditCard,
      description: 'Payment methods, billing, and refund information',
      color: 'green'
    },
    {
      id: 'returns',
      name: 'Returns & Exchanges',
      icon: RotateCcw,
      description: 'Return policy, exchanges, and refund process',
      color: 'purple'
    },
    {
      id: 'account',
      name: 'Account & Security',
      icon: Shield,
      description: 'Account settings, security, and privacy',
      color: 'red'
    }
  ];

  const faqs = [
    {
      id: 1,
      question: 'How do I track my order?',
      answer: 'You can track your order by logging into your account and visiting the "Orders" section, or by using the tracking number sent to your email.',
      category: 'orders',
      popular: true
    },
    {
      id: 2,
      question: 'What payment methods do you accept?',
      answer: 'We accept all major credit cards (Visa, MasterCard, American Express), PayPal, Apple Pay, and Google Pay.',
      category: 'payments',
      popular: true
    },
    {
      id: 3,
      question: 'How long does shipping take?',
      answer: 'Standard shipping takes 5-7 business days, while express shipping takes 2-3 business days. Free shipping is available on orders over $50.',
      category: 'orders',
      popular: true
    },
    {
      id: 4,
      question: 'What is your return policy?',
      answer: 'We offer a 30-day return policy for most items. Items must be in original condition with tags attached. Some restrictions apply.',
      category: 'returns',
      popular: true
    },
    {
      id: 5,
      question: 'How do I reset my password?',
      answer: 'Click on "Forgot Password" on the login page and enter your email address. We\'ll send you instructions to reset your password.',
      category: 'account',
      popular: false
    },
    {
      id: 6,
      question: 'Can I change or cancel my order?',
      answer: 'You can modify or cancel your order within 1 hour of placing it. After that, please contact customer service for assistance.',
      category: 'orders',
      popular: false
    },
    {
      id: 7,
      question: 'Do you ship internationally?',
      answer: 'Yes, we ship to over 25 countries worldwide. Shipping costs and delivery times vary by location.',
      category: 'orders',
      popular: false
    },
    {
      id: 8,
      question: 'How do I return an item?',
      answer: 'Log into your account, go to "Orders", find the item you want to return, and click "Return Item". Follow the instructions to print a return label.',
      category: 'returns',
      popular: false
    }
  ];

  const filteredFAQs = faqs.filter(faq => {
    const categoryMatch = selectedCategory === 'All' || faq.category === selectedCategory;
    const searchMatch = searchQuery === '' || 
      faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchQuery.toLowerCase());
    return categoryMatch && searchMatch;
  });

  const popularFAQs = faqs.filter(faq => faq.popular);

  const contactOptions = [
    {
      icon: MessageCircle,
      title: 'Live Chat',
      description: 'Chat with our support team',
      availability: 'Available 24/7',
      action: 'Start Chat'
    },
    {
      icon: Phone,
      title: 'Phone Support',
      description: 'Call us for immediate help',
      availability: 'Mon-Fri 9AM-6PM EST',
      action: 'Call Now'
    },
    {
      icon: Mail,
      title: 'Email Support',
      description: 'Send us a detailed message',
      availability: 'Response within 24 hours',
      action: 'Send Email'
    }
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-purple-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">Help Center</h1>
          <p className="text-xl md:text-2xl text-blue-100 max-w-3xl mx-auto mb-8">
            Find answers to your questions and get the help you need.
          </p>
          
          {/* Search Bar */}
          <div className="max-w-2xl mx-auto">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-6 h-6" />
              <input
                type="text"
                placeholder="Search for help articles..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-4 rounded-lg text-gray-900 text-lg focus:outline-none focus:ring-2 focus:ring-blue-300"
              />
            </div>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Help Categories */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">Browse by Category</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className="bg-white rounded-lg shadow-md p-6 text-left hover:shadow-lg transition-shadow duration-300 group"
              >
                <div className={`w-12 h-12 bg-${category.color}-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-${category.color}-200 transition-colors duration-300`}>
                  <category.icon className={`w-6 h-6 text-${category.color}-600`} />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{category.name}</h3>
                <p className="text-gray-600 text-sm">{category.description}</p>
                <div className="flex items-center mt-4 text-blue-600 group-hover:text-blue-700">
                  <span className="text-sm font-medium">Browse articles</span>
                  <ChevronRight className="w-4 h-4 ml-1" />
                </div>
              </button>
            ))}
          </div>
        </section>

        <div className="grid lg:grid-cols-3 gap-12">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Popular FAQs */}
            {selectedCategory === 'All' && searchQuery === '' && (
              <section className="mb-12">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Popular Questions</h2>
                <div className="space-y-4">
                  {popularFAQs.map((faq) => (
                    <div key={faq.id} className="bg-white rounded-lg shadow-md p-6">
                      <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
                        <HelpCircle className="w-5 h-5 text-blue-600 mr-2" />
                        {faq.question}
                      </h3>
                      <p className="text-gray-600">{faq.answer}</p>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* All FAQs */}
            <section>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-900">
                  {selectedCategory === 'All' ? 'All Questions' : `${categories.find(c => c.id === selectedCategory)?.name} Questions`}
                </h2>
                {selectedCategory !== 'All' && (
                  <button
                    onClick={() => setSelectedCategory('All')}
                    className="text-blue-600 hover:text-blue-700 font-medium"
                  >
                    View All Categories
                  </button>
                )}
              </div>

              <div className="space-y-4">
                {filteredFAQs.map((faq) => (
                  <div key={faq.id} className="bg-white rounded-lg shadow-md p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-3">{faq.question}</h3>
                    <p className="text-gray-600">{faq.answer}</p>
                  </div>
                ))}
              </div>

              {filteredFAQs.length === 0 && (
                <div className="text-center py-12">
                  <HelpCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No articles found</h3>
                  <p className="text-gray-600 mb-4">Try adjusting your search or browse our categories.</p>
                  <button 
                    onClick={() => {
                      setSearchQuery('');
                      setSelectedCategory('All');
                    }}
                    className="text-blue-600 hover:text-blue-700 font-medium"
                  >
                    Clear search
                  </button>
                </div>
              )}
            </section>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="space-y-8">
              {/* Contact Support */}
              <div className="bg-white rounded-lg shadow-md p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-6">Need More Help?</h3>
                <div className="space-y-4">
                  {contactOptions.map((option, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-4 hover:border-blue-300 transition-colors duration-200">
                      <div className="flex items-start space-x-3">
                        <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <option.icon className="w-5 h-5 text-blue-600" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900">{option.title}</h4>
                          <p className="text-sm text-gray-600 mb-1">{option.description}</p>
                          <p className="text-xs text-gray-500 mb-3">{option.availability}</p>
                          <button className="text-blue-600 hover:text-blue-700 text-sm font-medium">
                            {option.action}
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Quick Links */}
              <div className="bg-white rounded-lg shadow-md p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Links</h3>
                <div className="space-y-3">
                  <button 
                    onClick={() => onNavigate('track')}
                    className="block w-full text-left text-blue-600 hover:text-blue-700 font-medium"
                  >
                    Track Your Order
                  </button>
                  <button 
                    onClick={() => onNavigate('returns')}
                    className="block w-full text-left text-blue-600 hover:text-blue-700 font-medium"
                  >
                    Return an Item
                  </button>
                  <button 
                    onClick={() => onNavigate('shipping')}
                    className="block w-full text-left text-blue-600 hover:text-blue-700 font-medium"
                  >
                    Shipping Information
                  </button>
                  <button 
                    onClick={() => onNavigate('size-guide')}
                    className="block w-full text-left text-blue-600 hover:text-blue-700 font-medium"
                  >
                    Size Guide
                  </button>
                </div>
              </div>

              {/* Feedback */}
              <div className="bg-blue-50 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Help us improve</h3>
                <p className="text-gray-600 text-sm mb-4">
                  Did you find what you were looking for? Let us know how we can make our help center better.
                </p>
                <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200 text-sm font-medium">
                  Send Feedback
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HelpCenter;