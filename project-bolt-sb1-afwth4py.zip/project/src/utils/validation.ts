/**
 * Validation utilities for forms and user input
 */

export interface ValidationRule {
  required?: boolean;
  minLength?: number;
  maxLength?: number;
  pattern?: RegExp;
  custom?: (value: any) => string | null;
}

export interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
}

export class Validator {
  static validateField(value: any, rules: ValidationRule): string | null {
    // Required validation
    if (rules.required && (!value || (typeof value === 'string' && !value.trim()))) {
      return 'This field is required';
    }

    // Skip other validations if field is empty and not required
    if (!value || (typeof value === 'string' && !value.trim())) {
      return null;
    }

    const stringValue = String(value);

    // Min length validation
    if (rules.minLength && stringValue.length < rules.minLength) {
      return `Must be at least ${rules.minLength} characters`;
    }

    // Max length validation
    if (rules.maxLength && stringValue.length > rules.maxLength) {
      return `Must be no more than ${rules.maxLength} characters`;
    }

    // Pattern validation
    if (rules.pattern && !rules.pattern.test(stringValue)) {
      return 'Invalid format';
    }

    // Custom validation
    if (rules.custom) {
      return rules.custom(value);
    }

    return null;
  }

  static validateForm(data: Record<string, any>, rules: Record<string, ValidationRule>): ValidationResult {
    const errors: Record<string, string> = {};

    Object.entries(rules).forEach(([field, rule]) => {
      const error = this.validateField(data[field], rule);
      if (error) {
        errors[field] = error;
      }
    });

    return {
      isValid: Object.keys(errors).length === 0,
      errors,
    };
  }
}

// Common validation patterns
export const ValidationPatterns = {
  email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
  phone: /^\+?[\d\s\-\(\)]+$/,
  password: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d@$!%*?&]{8,}$/,
  zipCode: /^\d{5}(-\d{4})?$/,
  creditCard: /^\d{4}\s?\d{4}\s?\d{4}\s?\d{4}$/,
  cvv: /^\d{3,4}$/,
  expiryDate: /^(0[1-9]|1[0-2])\/\d{2}$/,
};

// Predefined validation rules
export const ValidationRules = {
  email: {
    required: true,
    pattern: ValidationPatterns.email,
    custom: (value: string) => {
      if (value && value.length > 254) {
        return 'Email address is too long';
      }
      return null;
    },
  },

  password: {
    required: true,
    minLength: 8,
    pattern: ValidationPatterns.password,
    custom: (value: string) => {
      if (!value) return null;
      if (!/(?=.*[a-z])/.test(value)) {
        return 'Password must contain at least one lowercase letter';
      }
      if (!/(?=.*[A-Z])/.test(value)) {
        return 'Password must contain at least one uppercase letter';
      }
      if (!/(?=.*\d)/.test(value)) {
        return 'Password must contain at least one number';
      }
      return null;
    },
  },

  confirmPassword: (originalPassword: string) => ({
    required: true,
    custom: (value: string) => {
      if (value !== originalPassword) {
        return 'Passwords do not match';
      }
      return null;
    },
  }),

  name: {
    required: true,
    minLength: 2,
    maxLength: 50,
    pattern: /^[a-zA-Z\s'-]+$/,
  },

  phone: {
    pattern: ValidationPatterns.phone,
    custom: (value: string) => {
      if (value && value.replace(/\D/g, '').length < 10) {
        return 'Phone number must be at least 10 digits';
      }
      return null;
    },
  },

  zipCode: {
    required: true,
    pattern: ValidationPatterns.zipCode,
  },

  creditCard: {
    required: true,
    pattern: ValidationPatterns.creditCard,
    custom: (value: string) => {
      if (!value) return null;
      // Luhn algorithm for credit card validation
      const digits = value.replace(/\D/g, '');
      let sum = 0;
      let isEven = false;
      
      for (let i = digits.length - 1; i >= 0; i--) {
        let digit = parseInt(digits[i]);
        
        if (isEven) {
          digit *= 2;
          if (digit > 9) {
            digit -= 9;
          }
        }
        
        sum += digit;
        isEven = !isEven;
      }
      
      return sum % 10 === 0 ? null : 'Invalid credit card number';
    },
  },

  cvv: {
    required: true,
    pattern: ValidationPatterns.cvv,
  },

  expiryDate: {
    required: true,
    pattern: ValidationPatterns.expiryDate,
    custom: (value: string) => {
      if (!value) return null;
      const [month, year] = value.split('/').map(Number);
      const currentDate = new Date();
      const currentYear = currentDate.getFullYear() % 100;
      const currentMonth = currentDate.getMonth() + 1;
      
      if (year < currentYear || (year === currentYear && month < currentMonth)) {
        return 'Card has expired';
      }
      
      return null;
    },
  },
};

// Form validation hook
export function useFormValidation<T extends Record<string, any>>(
  initialData: T,
  validationRules: Record<keyof T, ValidationRule>
) {
  const [data, setData] = React.useState<T>(initialData);
  const [errors, setErrors] = React.useState<Record<string, string>>({});
  const [touched, setTouched] = React.useState<Record<string, boolean>>({});

  const validateField = (field: keyof T, value: any) => {
    const rule = validationRules[field];
    if (!rule) return null;
    
    return Validator.validateField(value, rule);
  };

  const setFieldValue = (field: keyof T, value: any) => {
    setData(prev => ({ ...prev, [field]: value }));
    
    // Validate field if it has been touched
    if (touched[field as string]) {
      const error = validateField(field, value);
      setErrors(prev => ({
        ...prev,
        [field]: error || '',
      }));
    }
  };

  const setFieldTouched = (field: keyof T) => {
    setTouched(prev => ({ ...prev, [field]: true }));
    
    // Validate field when touched
    const error = validateField(field, data[field]);
    setErrors(prev => ({
      ...prev,
      [field]: error || '',
    }));
  };

  const validateForm = () => {
    const result = Validator.validateForm(data, validationRules);
    setErrors(result.errors);
    
    // Mark all fields as touched
    const allTouched = Object.keys(validationRules).reduce((acc, key) => {
      acc[key] = true;
      return acc;
    }, {} as Record<string, boolean>);
    setTouched(allTouched);
    
    return result.isValid;
  };

  const resetForm = () => {
    setData(initialData);
    setErrors({});
    setTouched({});
  };

  const isValid = Object.values(errors).every(error => !error);

  return {
    data,
    errors,
    touched,
    isValid,
    setFieldValue,
    setFieldTouched,
    validateForm,
    resetForm,
  };
}