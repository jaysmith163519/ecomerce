/**
 * Local storage utilities with error handling and type safety
 */

export class StorageManager {
  private static isStorageAvailable(type: 'localStorage' | 'sessionStorage'): boolean {
    try {
      const storage = window[type];
      const test = '__storage_test__';
      storage.setItem(test, test);
      storage.removeItem(test);
      return true;
    } catch {
      return false;
    }
  }

  static setItem(key: string, value: any, useSession = false): boolean {
    const storageType = useSession ? 'sessionStorage' : 'localStorage';
    
    if (!this.isStorageAvailable(storageType)) {
      console.warn(`${storageType} is not available`);
      return false;
    }

    try {
      const serializedValue = JSON.stringify(value);
      window[storageType].setItem(key, serializedValue);
      return true;
    } catch (error) {
      console.error(`Error saving to ${storageType}:`, error);
      return false;
    }
  }

  static getItem<T>(key: string, defaultValue: T | null = null, useSession = false): T | null {
    const storageType = useSession ? 'sessionStorage' : 'localStorage';
    
    if (!this.isStorageAvailable(storageType)) {
      return defaultValue;
    }

    try {
      const item = window[storageType].getItem(key);
      if (item === null) {
        return defaultValue;
      }
      return JSON.parse(item);
    } catch (error) {
      console.error(`Error reading from ${storageType}:`, error);
      return defaultValue;
    }
  }

  static removeItem(key: string, useSession = false): boolean {
    const storageType = useSession ? 'sessionStorage' : 'localStorage';
    
    if (!this.isStorageAvailable(storageType)) {
      return false;
    }

    try {
      window[storageType].removeItem(key);
      return true;
    } catch (error) {
      console.error(`Error removing from ${storageType}:`, error);
      return false;
    }
  }

  static clear(useSession = false): boolean {
    const storageType = useSession ? 'sessionStorage' : 'localStorage';
    
    if (!this.isStorageAvailable(storageType)) {
      return false;
    }

    try {
      window[storageType].clear();
      return true;
    } catch (error) {
      console.error(`Error clearing ${storageType}:`, error);
      return false;
    }
  }

  static getAllKeys(useSession = false): string[] {
    const storageType = useSession ? 'sessionStorage' : 'localStorage';
    
    if (!this.isStorageAvailable(storageType)) {
      return [];
    }

    try {
      const keys: string[] = [];
      const storage = window[storageType];
      for (let i = 0; i < storage.length; i++) {
        const key = storage.key(i);
        if (key) keys.push(key);
      }
      return keys;
    } catch (error) {
      console.error(`Error getting keys from ${storageType}:`, error);
      return [];
    }
  }
}

// Convenience functions for common storage operations
export const storage = {
  // User preferences
  setUserPreferences: (preferences: any) => 
    StorageManager.setItem('userPreferences', preferences),
  getUserPreferences: () => 
    StorageManager.getItem('userPreferences', {}),

  // Shopping cart (for guest users)
  setGuestCart: (cart: any) => 
    StorageManager.setItem('guestCart', cart),
  getGuestCart: () => 
    StorageManager.getItem('guestCart', { items: [] }),
  clearGuestCart: () => 
    StorageManager.removeItem('guestCart'),

  // Recently viewed products
  setRecentlyViewed: (products: any[]) => 
    StorageManager.setItem('recentlyViewed', products),
  getRecentlyViewed: () => 
    StorageManager.getItem('recentlyViewed', []),
  addToRecentlyViewed: (product: any) => {
    const recent = storage.getRecentlyViewed();
    const filtered = recent.filter((p: any) => p.id !== product.id);
    const updated = [product, ...filtered].slice(0, 10); // Keep last 10
    storage.setRecentlyViewed(updated);
  },

  // Search history
  setSearchHistory: (searches: string[]) => 
    StorageManager.setItem('searchHistory', searches),
  getSearchHistory: () => 
    StorageManager.getItem('searchHistory', []),
  addToSearchHistory: (query: string) => {
    if (!query.trim()) return;
    const history = storage.getSearchHistory();
    const filtered = history.filter((q: string) => q !== query);
    const updated = [query, ...filtered].slice(0, 10); // Keep last 10
    storage.setSearchHistory(updated);
  },

  // Theme preference
  setTheme: (theme: 'light' | 'dark' | 'system') => 
    StorageManager.setItem('theme', theme),
  getTheme: () => 
    StorageManager.getItem('theme', 'system'),

  // Language preference
  setLanguage: (language: string) => 
    StorageManager.setItem('language', language),
  getLanguage: () => 
    StorageManager.getItem('language', 'en'),
};