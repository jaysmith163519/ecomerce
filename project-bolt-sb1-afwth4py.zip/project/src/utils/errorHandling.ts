import { ApiError } from '../types/api.types';

/**
 * Error handling utilities for API responses
 */

export class AppError extends Error {
  public status?: number;
  public data?: any;

  constructor(message: string, status?: number, data?: any) {
    super(message);
    this.name = 'AppError';
    this.status = status;
    this.data = data;
  }
}

/**
 * Transform API error to user-friendly message
 */
export function getErrorMessage(error: ApiError | Error | any): string {
  if (error instanceof AppError) {
    return error.message;
  }

  if (error?.message) {
    return error.message;
  }

  if (error?.response?.data?.message) {
    return error.response.data.message;
  }

  if (error?.status) {
    switch (error.status) {
      case 400:
        return 'Invalid request. Please check your input.';
      case 401:
        return 'You need to log in to access this resource.';
      case 403:
        return 'You don\'t have permission to access this resource.';
      case 404:
        return 'The requested resource was not found.';
      case 409:
        return 'This action conflicts with existing data.';
      case 422:
        return 'The provided data is invalid.';
      case 429:
        return 'Too many requests. Please try again later.';
      case 500:
        return 'Server error. Please try again later.';
      case 503:
        return 'Service temporarily unavailable. Please try again later.';
      default:
        return 'An unexpected error occurred. Please try again.';
    }
  }

  return 'An unexpected error occurred. Please try again.';
}

/**
 * Check if error is a network error
 */
export function isNetworkError(error: any): boolean {
  return !error.response && error.request;
}

/**
 * Check if error is a timeout error
 */
export function isTimeoutError(error: any): boolean {
  return error.code === 'ECONNABORTED' || error.message?.includes('timeout');
}

/**
 * Check if error is retryable
 */
export function isRetryableError(error: any): boolean {
  if (isNetworkError(error) || isTimeoutError(error)) {
    return true;
  }

  const status = error.status || error.response?.status;
  return status >= 500 || status === 429;
}

/**
 * Extract validation errors from API response
 */
export function extractValidationErrors(error: any): Record<string, string> {
  const errors: Record<string, string> = {};

  if (error?.data?.errors) {
    // Handle express-validator errors
    if (Array.isArray(error.data.errors)) {
      error.data.errors.forEach((err: any) => {
        if (err.param && err.msg) {
          errors[err.param] = err.msg;
        }
      });
    } else if (typeof error.data.errors === 'object') {
      // Handle object-based validation errors
      Object.entries(error.data.errors).forEach(([field, message]) => {
        errors[field] = String(message);
      });
    }
  }

  return errors;
}

/**
 * Log error for debugging (in development)
 */
export function logError(error: any, context?: string): void {
  if (process.env.NODE_ENV === 'development') {
    console.group(`🚨 Error${context ? ` in ${context}` : ''}`);
    console.error('Error:', error);
    if (error?.response) {
      console.error('Response:', error.response);
    }
    if (error?.request) {
      console.error('Request:', error.request);
    }
    console.groupEnd();
  }
}

/**
 * Create error notification object
 */
export function createErrorNotification(error: any) {
  return {
    type: 'error' as const,
    title: 'Error',
    message: getErrorMessage(error),
    duration: 5000,
  };
}

/**
 * Handle form validation errors
 */
export function handleFormErrors(
  error: any,
  setFieldError: (field: string, message: string) => void
): void {
  const validationErrors = extractValidationErrors(error);
  
  Object.entries(validationErrors).forEach(([field, message]) => {
    setFieldError(field, message);
  });
}

/**
 * Retry function with exponential backoff
 */
export async function retryWithBackoff<T>(
  fn: () => Promise<T>,
  maxRetries: number = 3,
  baseDelay: number = 1000
): Promise<T> {
  let lastError: any;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error;
      
      if (attempt === maxRetries || !isRetryableError(error)) {
        throw error;
      }

      const delay = baseDelay * Math.pow(2, attempt);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }

  throw lastError;
}

/**
 * Error boundary helper
 */
export function createErrorBoundaryFallback(error: Error, errorInfo: any) {
  logError(error, 'Error Boundary');
  
  return {
    hasError: true,
    error,
    errorInfo,
    message: getErrorMessage(error),
  };
}

/**
 * Global error handler for unhandled promise rejections
 */
export function setupGlobalErrorHandling(): void {
  window.addEventListener('unhandledrejection', (event) => {
    logError(event.reason, 'Unhandled Promise Rejection');
    
    // Prevent the default browser behavior
    event.preventDefault();
  });

  window.addEventListener('error', (event) => {
    logError(event.error, 'Global Error');
  });
}