export const products = [
  {
    id: 1,
    name: "Smart Watch Series 5",
    price: 199.99,
    originalPrice: 249.99,
    image: "https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?auto=compress&cs=tinysrgb&w=500",
    rating: 4.8,
    reviews: 124,
    category: "Electronics",
    inStock: true
  },
  {
    id: 2,
    name: "Ultra Boost Running Shoes",
    price: 129.99,
    originalPrice: 159.99,
    image: "https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=500",
    rating: 4.6,
    reviews: 89,
    category: "Fashion",
    inStock: true
  },
  {
    id: 3,
    name: "Wireless Noise-Canceling Headphones",
    price: 249.99,
    image: "https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=500",
    rating: 4.9,
    reviews: 156,
    category: "Electronics",
    inStock: true
  },
  {
    id: 4,
    name: "Premium Leather Backpack",
    price: 89.99,
    originalPrice: 119.99,
    image: "https://images.pexels.com/photos/2905238/pexels-photo-2905238.jpeg?auto=compress&cs=tinysrgb&w=500",
    rating: 4.4,
    reviews: 67,
    category: "Fashion",
    inStock: true
  },
  {
    id: 5,
    name: "4K Wireless Security Camera",
    price: 179.99,
    image: "https://images.pexels.com/photos/430208/pexels-photo-430208.jpeg?auto=compress&cs=tinysrgb&w=500",
    rating: 4.7,
    reviews: 98,
    category: "Electronics",
    inStock: true
  },
  {
    id: 6,
    name: "Organic Cotton T-Shirt",
    price: 24.99,
    originalPrice: 34.99,
    image: "https://images.pexels.com/photos/1183266/pexels-photo-1183266.jpeg?auto=compress&cs=tinysrgb&w=500",
    rating: 4.3,
    reviews: 203,
    category: "Fashion",
    inStock: true
  },
  {
    id: 7,
    name: "Smart Home Hub",
    price: 99.99,
    image: "https://images.pexels.com/photos/159304/network-cable-ethernet-computer-159304.jpeg?auto=compress&cs=tinysrgb&w=500",
    rating: 4.5,
    reviews: 134,
    category: "Electronics",
    inStock: true
  },
  {
    id: 8,
    name: "Yoga Mat Premium",
    price: 39.99,
    originalPrice: 59.99,
    image: "https://images.pexels.com/photos/3822906/pexels-photo-3822906.jpeg?auto=compress&cs=tinysrgb&w=500",
    rating: 4.6,
    reviews: 78,
    category: "Sports",
    inStock: true
  },
  {
    id: 9,
    name: "Bluetooth Portable Speaker",
    price: 79.99,
    image: "https://images.pexels.com/photos/1649771/pexels-photo-1649771.jpeg?auto=compress&cs=tinysrgb&w=500",
    rating: 4.4,
    reviews: 145,
    category: "Electronics",
    inStock: true
  },
  {
    id: 10,
    name: "Designer Sunglasses",
    price: 149.99,
    originalPrice: 199.99,
    image: "https://images.pexels.com/photos/701877/pexels-photo-701877.jpeg?auto=compress&cs=tinysrgb&w=500",
    rating: 4.7,
    reviews: 92,
    category: "Fashion",
    inStock: true
  },
  {
    id: 11,
    name: "Stainless Steel Water Bottle",
    price: 29.99,
    image: "https://images.pexels.com/photos/3766227/pexels-photo-3766227.jpeg?auto=compress&cs=tinysrgb&w=500",
    rating: 4.5,
    reviews: 167,
    category: "Sports",
    inStock: true
  },
  {
    id: 12,
    name: "Gaming Mechanical Keyboard",
    price: 129.99,
    originalPrice: 169.99,
    image: "https://images.pexels.com/photos/1194713/pexels-photo-1194713.jpeg?auto=compress&cs=tinysrgb&w=500",
    rating: 4.8,
    reviews: 234,
    category: "Electronics",
    inStock: true
  },
  {
    id: 13,
    name: "Cotton Hoodie",
    price: 59.99,
    image: "https://images.pexels.com/photos/996329/pexels-photo-996329.jpeg?auto=compress&cs=tinysrgb&w=500",
    rating: 4.2,
    reviews: 112,
    category: "Fashion",
    inStock: true
  },
  {
    id: 14,
    name: "LED Desk Lamp",
    price: 49.99,
    originalPrice: 69.99,
    image: "https://images.pexels.com/photos/1112598/pexels-photo-1112598.jpeg?auto=compress&cs=tinysrgb&w=500",
    rating: 4.6,
    reviews: 87,
    category: "Home & Garden",
    inStock: true
  },
  {
    id: 15,
    name: "Fitness Tracker Band",
    price: 89.99,
    image: "https://images.pexels.com/photos/267350/pexels-photo-267350.jpeg?auto=compress&cs=tinysrgb&w=500",
    rating: 4.3,
    reviews: 156,
    category: "Electronics",
    inStock: true
  },
  {
    id: 16,
    name: "Canvas Tote Bag",
    price: 19.99,
    originalPrice: 29.99,
    image: "https://images.pexels.com/photos/1152077/pexels-photo-1152077.jpeg?auto=compress&cs=tinysrgb&w=500",
    rating: 4.1,
    reviews: 89,
    category: "Fashion",
    inStock: true
  }
];