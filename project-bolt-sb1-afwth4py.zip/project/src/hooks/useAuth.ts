import { useState, useEffect, useCallback } from 'react';
import { useApi } from './useApi';
import authService from '../services/authService';
import { User, LoginRequest, RegisterRequest } from '../types/api.types';

interface UseAuthReturn {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  login: (credentials: LoginRequest) => Promise<void>;
  register: (userData: RegisterRequest) => Promise<void>;
  logout: () => void;
  updateProfile: (data: Partial<User>) => Promise<void>;
  refreshProfile: () => Promise<void>;
  changePassword: (currentPassword: string, newPassword: string) => Promise<void>;
}

export function useAuth(): UseAuthReturn {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Initialize auth state
  useEffect(() => {
    const initializeAuth = () => {
      const isAuth = authService.isAuthenticated();
      const currentUser = authService.getCurrentUser();
      
      setIsAuthenticated(isAuth);
      setUser(currentUser);
    };

    initializeAuth();
  }, []);

  // Login
  const {
    execute: executeLogin,
    isLoading: loginLoading,
    error: loginError,
  } = useApi(authService.login.bind(authService), {
    onSuccess: (response) => {
      setUser(response.user);
      setIsAuthenticated(true);
    },
  });

  // Register
  const {
    execute: executeRegister,
    isLoading: registerLoading,
    error: registerError,
  } = useApi(authService.register.bind(authService), {
    onSuccess: (response) => {
      setUser(response.user);
      setIsAuthenticated(true);
    },
  });

  // Update profile
  const {
    execute: executeUpdateProfile,
    isLoading: updateLoading,
    error: updateError,
  } = useApi(authService.updateProfile.bind(authService), {
    onSuccess: (updatedUser) => {
      setUser(updatedUser);
    },
  });

  // Refresh profile
  const {
    execute: executeRefreshProfile,
    isLoading: refreshLoading,
    error: refreshError,
  } = useApi(authService.refreshProfile.bind(authService), {
    onSuccess: (updatedUser) => {
      setUser(updatedUser);
    },
  });

  // Change password
  const {
    execute: executeChangePassword,
    isLoading: changePasswordLoading,
    error: changePasswordError,
  } = useApi(authService.changePassword.bind(authService));

  // Wrapper functions
  const login = useCallback(async (credentials: LoginRequest) => {
    await executeLogin(credentials);
  }, [executeLogin]);

  const register = useCallback(async (userData: RegisterRequest) => {
    await executeRegister(userData);
  }, [executeRegister]);

  const logout = useCallback(() => {
    authService.logout();
    setUser(null);
    setIsAuthenticated(false);
  }, []);

  const updateProfile = useCallback(async (data: Partial<User>) => {
    await executeUpdateProfile(data);
  }, [executeUpdateProfile]);

  const refreshProfile = useCallback(async () => {
    await executeRefreshProfile();
  }, [executeRefreshProfile]);

  const changePassword = useCallback(async (currentPassword: string, newPassword: string) => {
    await executeChangePassword({ currentPassword, newPassword });
  }, [executeChangePassword]);

  // Combine loading states
  const isLoading = loginLoading || registerLoading || updateLoading || 
                   refreshLoading || changePasswordLoading;

  // Combine error states
  const error = loginError || registerError || updateError || 
               refreshError || changePasswordError;

  return {
    user,
    isAuthenticated,
    isLoading,
    error,
    login,
    register,
    logout,
    updateProfile,
    refreshProfile,
    changePassword,
  };
}