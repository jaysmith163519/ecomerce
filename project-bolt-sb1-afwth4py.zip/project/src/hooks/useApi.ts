import { useState, useEffect, useCallback, useRef } from 'react';
import { ApiError, LoadingState } from '../types/api.types';

interface UseApiState<T> extends LoadingState {
  data: T | null;
}

interface UseApiOptions {
  immediate?: boolean;
  onSuccess?: (data: any) => void;
  onError?: (error: ApiError) => void;
  retryCount?: number;
  retryDelay?: number;
}

export function useApi<T>(
  apiFunction: (...args: any[]) => Promise<T>,
  options: UseApiOptions = {}
) {
  const { 
    immediate = false, 
    onSuccess, 
    onError, 
    retryCount = 0, 
    retryDelay = 1000 
  } = options;
  
  const [state, setState] = useState<UseApiState<T>>({
    data: null,
    isLoading: false,
    error: null,
  });
  
  const cancelTokenRef = useRef<AbortController | null>(null);
  const mountedRef = useRef(true);
  const retryTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const execute = useCallback(async (...args: any[]): Promise<T | undefined> => {
    // Cancel previous request
    if (cancelTokenRef.current) {
      cancelTokenRef.current.abort();
    }
    
    // Clear retry timeout
    if (retryTimeoutRef.current) {
      clearTimeout(retryTimeoutRef.current);
    }
    
    // Create new cancel token
    cancelTokenRef.current = new AbortController();
    
    setState(prev => ({ ...prev, isLoading: true, error: null }));
    
    const attemptRequest = async (attempt: number = 0): Promise<T | undefined> => {
      try {
        const result = await apiFunction(...args);
        
        if (mountedRef.current) {
          setState({
            data: result,
            isLoading: false,
            error: null,
          });
          
          if (onSuccess) {
            onSuccess(result);
          }
        }
        
        return result;
      } catch (error: any) {
        if (mountedRef.current && error.name !== 'AbortError') {
          // Retry logic for network errors
          if (attempt < retryCount && 
              (error.status >= 500 || !error.status)) {
            return new Promise((resolve) => {
              retryTimeoutRef.current = setTimeout(() => {
                resolve(attemptRequest(attempt + 1));
              }, retryDelay * (attempt + 1));
            });
          }
          
          const errorMessage = error.message || 'An error occurred';
          setState({
            data: null,
            isLoading: false,
            error: errorMessage,
          });
          
          if (onError) {
            onError(error);
          }
        }
        throw error;
      }
    };
    
    return attemptRequest();
  }, [apiFunction, onSuccess, onError, retryCount, retryDelay]);

  const reset = useCallback(() => {
    setState({
      data: null,
      isLoading: false,
      error: null,
    });
  }, []);

  const retry = useCallback(() => {
    if (state.error) {
      execute();
    }
  }, [execute, state.error]);

  useEffect(() => {
    if (immediate) {
      execute();
    }
    
    return () => {
      mountedRef.current = false;
      if (cancelTokenRef.current) {
        cancelTokenRef.current.abort();
      }
      if (retryTimeoutRef.current) {
        clearTimeout(retryTimeoutRef.current);
      }
    };
  }, [execute, immediate]);

  useEffect(() => {
    return () => {
      mountedRef.current = false;
    };
  }, []);

  return {
    ...state,
    execute,
    reset,
    retry,
  };
}

// Hook for paginated API calls
export function usePaginatedApi<T>(
  apiFunction: (page: number, ...args: any[]) => Promise<{ data: T[]; pagination: any }>,
  options: UseApiOptions & { pageSize?: number } = {}
) {
  const { pageSize = 10, ...apiOptions } = options;
  const [state, setState] = useState({
    data: [] as T[],
    isLoading: false,
    error: null as string | null,
    hasMore: true,
    page: 1,
    totalPages: 0,
    isLoadingMore: false,
  });

  const loadMore = useCallback(async (...args: any[]) => {
    if (state.isLoading || state.isLoadingMore || !state.hasMore) return;

    const isFirstLoad = state.page === 1 && state.data.length === 0;
    setState(prev => ({ 
      ...prev, 
      isLoading: isFirstLoad, 
      isLoadingMore: !isFirstLoad,
      error: null 
    }));

    try {
      const result = await apiFunction(state.page, ...args);
      
      setState(prev => ({
        ...prev,
        data: prev.page === 1 ? result.data : [...prev.data, ...result.data],
        isLoading: false,
        isLoadingMore: false,
        hasMore: result.pagination.hasNext,
        page: prev.page + 1,
        totalPages: result.pagination.totalPages,
      }));
    } catch (error: any) {
      setState(prev => ({
        ...prev,
        isLoading: false,
        isLoadingMore: false,
        error: error.message || 'An error occurred',
      }));
    }
  }, [apiFunction, state.isLoading, state.isLoadingMore, state.hasMore, state.page]);

  const reset = useCallback(() => {
    setState({
      data: [],
      isLoading: false,
      error: null,
      hasMore: true,
      page: 1,
      totalPages: 0,
      isLoadingMore: false,
    });
  }, []);

  const refresh = useCallback(async (...args: any[]) => {
    setState(prev => ({
      ...prev,
      page: 1,
      hasMore: true,
      data: [],
    }));
    await loadMore(...args);
  }, [loadMore]);

  return {
    ...state,
    loadMore,
    reset,
    refresh,
  };
}

// Hook for debounced API calls (useful for search)
export function useDebouncedApi<T>(
  apiFunction: (...args: any[]) => Promise<T>,
  delay: number = 300,
  options: UseApiOptions = {}
) {
  const [debouncedArgs, setDebouncedArgs] = useState<any[]>([]);
  const timeoutRef = useRef<NodeJS.Timeout>();
  
  const { data, isLoading, error, execute } = useApi(apiFunction, {
    ...options,
    immediate: false,
  });

  const debouncedExecute = useCallback((...args: any[]) => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    
    timeoutRef.current = setTimeout(() => {
      setDebouncedArgs(args);
    }, delay);
  }, [delay]);

  const cancelDebounce = useCallback(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
  }, []);

  useEffect(() => {
    if (debouncedArgs.length > 0) {
      execute(...debouncedArgs);
    }
  }, [debouncedArgs, execute]);

  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);

  return {
    data,
    isLoading,
    error,
    execute: debouncedExecute,
    cancelDebounce,
  };
}

// Hook for optimistic updates
export function useOptimisticApi<T>(
  apiFunction: (...args: any[]) => Promise<T>,
  options: UseApiOptions = {}
) {
  const { data, isLoading, error, execute } = useApi(apiFunction, options);
  const [optimisticData, setOptimisticData] = useState<T | null>(null);

  const executeOptimistic = useCallback(async (
    optimisticValue: T,
    ...args: any[]
  ) => {
    setOptimisticData(optimisticValue);
    
    try {
      const result = await execute(...args);
      setOptimisticData(null);
      return result;
    } catch (error) {
      setOptimisticData(null);
      throw error;
    }
  }, [execute]);

  return {
    data: optimisticData || data,
    isLoading,
    error,
    execute: executeOptimistic,
    isOptimistic: optimisticData !== null,
  };
}