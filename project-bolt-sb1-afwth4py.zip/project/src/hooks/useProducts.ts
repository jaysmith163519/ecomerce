import { useState, useCallback } from 'react';
import { usePaginatedApi, useDebouncedApi } from './useApi';
import productService from '../services/productService';
import { Product, ProductsQuery, Category } from '../types/api.types';

interface UseProductsReturn {
  products: Product[];
  isLoading: boolean;
  isLoadingMore: boolean;
  error: string | null;
  hasMore: boolean;
  totalPages: number;
  loadMore: (query?: ProductsQuery) => Promise<void>;
  refresh: (query?: ProductsQuery) => Promise<void>;
  reset: () => void;
}

interface UseProductSearchReturn {
  searchResults: Product[];
  isSearching: boolean;
  searchError: string | null;
  search: (query: string, filters?: Omit<ProductsQuery, 'search'>) => void;
  clearSearch: () => void;
}

export function useProducts(): UseProductsReturn {
  const {
    data: products,
    isLoading,
    isLoadingMore,
    error,
    hasMore,
    totalPages,
    loadMore: loadMoreProducts,
    refresh: refreshProducts,
    reset,
  } = usePaginatedApi(
    (page: number, query: ProductsQuery = {}) => 
      productService.getProducts({ ...query, page }),
    { pageSize: 12 }
  );

  const loadMore = useCallback(async (query: ProductsQuery = {}) => {
    await loadMoreProducts(query);
  }, [loadMoreProducts]);

  const refresh = useCallback(async (query: ProductsQuery = {}) => {
    await refreshProducts(query);
  }, [refreshProducts]);

  return {
    products,
    isLoading,
    isLoadingMore,
    error,
    hasMore,
    totalPages,
    loadMore,
    refresh,
    reset,
  };
}

export function useProductSearch(): UseProductSearchReturn {
  const [searchResults, setSearchResults] = useState<Product[]>([]);

  const {
    data,
    isLoading: isSearching,
    error: searchError,
    execute: executeSearch,
  } = useDebouncedApi(
    (searchTerm: string, filters: Omit<ProductsQuery, 'search'> = {}) =>
      productService.searchProducts(searchTerm, filters),
    300,
    {
      onSuccess: (response) => {
        setSearchResults(response.products);
      },
    }
  );

  const search = useCallback((
    query: string, 
    filters: Omit<ProductsQuery, 'search'> = {}
  ) => {
    if (query.trim()) {
      executeSearch(query, filters);
    } else {
      setSearchResults([]);
    }
  }, [executeSearch]);

  const clearSearch = useCallback(() => {
    setSearchResults([]);
  }, []);

  return {
    searchResults,
    isSearching,
    searchError,
    search,
    clearSearch,
  };
}

export function useProductCategories() {
  const {
    data: categories,
    isLoading,
    error,
    execute: loadCategories,
  } = useApi(productService.getCategories.bind(productService), {
    immediate: true,
  });

  return {
    categories: categories || [],
    isLoading,
    error,
    refresh: loadCategories,
  };
}

export function useFeaturedProducts(limit: number = 8) {
  const {
    data: featuredProducts,
    isLoading,
    error,
    execute: loadFeaturedProducts,
  } = useApi(
    () => productService.getFeaturedProducts(limit),
    { immediate: true }
  );

  return {
    featuredProducts: featuredProducts || [],
    isLoading,
    error,
    refresh: loadFeaturedProducts,
  };
}

export function useRelatedProducts(productId: string, limit: number = 4) {
  const {
    data: relatedProducts,
    isLoading,
    error,
    execute: loadRelatedProducts,
  } = useApi(
    () => productService.getRelatedProducts(productId, limit),
    { immediate: !!productId }
  );

  return {
    relatedProducts: relatedProducts || [],
    isLoading,
    error,
    refresh: loadRelatedProducts,
  };
}