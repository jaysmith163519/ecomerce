import { useState, useEffect, useCallback } from 'react';
import { useApi } from './useApi';
import cartService from '../services/cartService';
import { Cart, AddToCartRequest, UpdateCartItemRequest } from '../types/api.types';

interface UseCartReturn {
  cart: Cart | null;
  isLoading: boolean;
  error: string | null;
  itemCount: number;
  totalPrice: number;
  addToCart: (item: AddToCartRequest) => Promise<void>;
  updateCartItem: (itemId: string, quantity: number) => Promise<void>;
  removeFromCart: (itemId: string) => Promise<void>;
  clearCart: () => Promise<void>;
  refreshCart: () => Promise<void>;
  applyCoupon: (code: string) => Promise<void>;
  removeCoupon: () => Promise<void>;
}

export function useCart(): UseCartReturn {
  const [cart, setCart] = useState<Cart | null>(null);

  // Get cart
  const {
    data: cartData,
    execute: executeGetCart,
    isLoading: getCartLoading,
    error: getCartError,
  } = useApi(cartService.getCart.bind(cartService), {
    onSuccess: (cartData) => {
      setCart(cartData);
    },
  });

  // Add to cart
  const {
    execute: executeAddToCart,
    isLoading: addToCartLoading,
    error: addToCartError,
  } = useApi(cartService.addToCart.bind(cartService), {
    onSuccess: (updatedCart) => {
      setCart(updatedCart);
    },
  });

  // Update cart item
  const {
    execute: executeUpdateCartItem,
    isLoading: updateCartLoading,
    error: updateCartError,
  } = useApi(cartService.updateCartItem.bind(cartService), {
    onSuccess: (updatedCart) => {
      setCart(updatedCart);
    },
  });

  // Remove from cart
  const {
    execute: executeRemoveFromCart,
    isLoading: removeFromCartLoading,
    error: removeFromCartError,
  } = useApi(cartService.removeFromCart.bind(cartService), {
    onSuccess: (updatedCart) => {
      setCart(updatedCart);
    },
  });

  // Clear cart
  const {
    execute: executeClearCart,
    isLoading: clearCartLoading,
    error: clearCartError,
  } = useApi(cartService.clearCart.bind(cartService), {
    onSuccess: () => {
      setCart(null);
    },
  });

  // Apply coupon
  const {
    execute: executeApplyCoupon,
    isLoading: applyCouponLoading,
    error: applyCouponError,
  } = useApi(cartService.applyCoupon.bind(cartService), {
    onSuccess: (updatedCart) => {
      setCart(updatedCart);
    },
  });

  // Remove coupon
  const {
    execute: executeRemoveCoupon,
    isLoading: removeCouponLoading,
    error: removeCouponError,
  } = useApi(cartService.removeCoupon.bind(cartService), {
    onSuccess: (updatedCart) => {
      setCart(updatedCart);
    },
  });

  // Initialize cart on mount
  useEffect(() => {
    executeGetCart();
  }, [executeGetCart]);

  // Wrapper functions
  const addToCart = useCallback(async (item: AddToCartRequest) => {
    await executeAddToCart(item);
  }, [executeAddToCart]);

  const updateCartItem = useCallback(async (itemId: string, quantity: number) => {
    const updateData: UpdateCartItemRequest = { quantity };
    await executeUpdateCartItem(itemId, updateData);
  }, [executeUpdateCartItem]);

  const removeFromCart = useCallback(async (itemId: string) => {
    await executeRemoveFromCart(itemId);
  }, [executeRemoveFromCart]);

  const clearCart = useCallback(async () => {
    await executeClearCart();
  }, [executeClearCart]);

  const refreshCart = useCallback(async () => {
    await executeGetCart();
  }, [executeGetCart]);

  const applyCoupon = useCallback(async (code: string) => {
    await executeApplyCoupon(code);
  }, [executeApplyCoupon]);

  const removeCoupon = useCallback(async () => {
    await executeRemoveCoupon();
  }, [executeRemoveCoupon]);

  // Combine loading states
  const isLoading = getCartLoading || addToCartLoading || updateCartLoading || 
                   removeFromCartLoading || clearCartLoading || applyCouponLoading || 
                   removeCouponLoading;

  // Combine error states
  const error = getCartError || addToCartError || updateCartError || 
               removeFromCartError || clearCartError || applyCouponError || 
               removeCouponError;

  // Computed values
  const itemCount = cart?.totalItems || 0;
  const totalPrice = cart?.totalPrice || 0;

  return {
    cart,
    isLoading,
    error,
    itemCount,
    totalPrice,
    addToCart,
    updateCartItem,
    removeFromCart,
    clearCart,
    refreshCart,
    applyCoupon,
    removeCoupon,
  };
}